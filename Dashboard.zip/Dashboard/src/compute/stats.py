"""Trend, detrending and correlation helpers built on the ``statistics`` stdlib.

``statistics.linear_regression`` and ``statistics.correlation`` exist in
Python 3.10+, so no numpy/pandas is required.
"""
import math
import statistics


def _ok(v):
    """True for a real, finite number (rejects None, NaN, Inf, bools)."""
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def linear_trend(xs, ys):
    """Fit y = slope*x + intercept. Returns (slope, intercept) or None."""
    pairs = [(x, y) for x, y in zip(xs, ys) if _ok(x) and _ok(y)]
    if len(pairs) < 2:
        return None
    fx = [p[0] for p in pairs]
    fy = [p[1] for p in pairs]
    try:
        res = statistics.linear_regression(fx, fy)
        return (res.slope, res.intercept)
    except statistics.StatisticsError:
        return None


def trend_line(xs, slope, intercept):
    """Evaluate the fitted line at each x (None where x is None)."""
    return [
        round(slope * x + intercept, 3) if x is not None else None for x in xs
    ]


def detrend(xs, ys, slope, intercept):
    """Residuals: actual - fitted. Captures the real year-to-year change."""
    out = []
    for x, y in zip(xs, ys):
        if x is None or y is None:
            out.append(None)
        else:
            out.append(round(y - (slope * x + intercept), 3))
    return out


def pearson(xs, ys):
    """Pearson r over paired finite values, or None if not computable."""
    pairs = [(x, y) for x, y in zip(xs, ys) if _ok(x) and _ok(y)]
    if len(pairs) < 3:
        return None
    fx = [p[0] for p in pairs]
    fy = [p[1] for p in pairs]
    # correlation needs variation in both variables
    if len(set(fx)) < 2 or len(set(fy)) < 2:
        return None
    try:
        return round(statistics.correlation(fx, fy), 4)
    except statistics.StatisticsError:
        return None


def regression_endpoints(xs, ys):
    """Return [[x_min, y_at_min], [x_max, y_at_max]] for a fitted line, or None."""
    pairs = [(x, y) for x, y in zip(xs, ys) if _ok(x) and _ok(y)]
    if len(pairs) < 2:
        return None
    fx = [p[0] for p in pairs]
    fy = [p[1] for p in pairs]
    fit = linear_trend(fx, fy)
    if not fit:
        return None
    slope, intercept = fit
    x0, x1 = min(fx), max(fx)
    return [[round(x0, 3), round(slope * x0 + intercept, 3)],
            [round(x1, 3), round(slope * x1 + intercept, 3)]]


def correlation_clean(xs, ys, z=2.0, max_frac=0.2):
    """Robust Pearson r with statistical outliers trimmed.

    Fits y~x, flags points whose residual exceeds z·σ (capped at ``max_frac`` of
    points and never dropping below 6 remaining), and returns r on the trimmed
    set, r on all points, the fitted line, and per-point outlier flags — so the
    trimming is transparent rather than hidden cherry-picking.
    """
    pairs = [(x, y) for x, y in zip(xs, ys) if _ok(x) and _ok(y)]
    n = len(pairs)
    if n < 4 or len({p[0] for p in pairs}) < 2 or len({p[1] for p in pairs}) < 2:
        return None
    fx = [p[0] for p in pairs]
    fy = [p[1] for p in pairs]
    flags = [False] * n
    fit = linear_trend(fx, fy)
    if fit:
        slope, intercept = fit
        resid = [fy[i] - (slope * fx[i] + intercept) for i in range(n)]
        try:
            sd = statistics.pstdev(resid)
        except statistics.StatisticsError:
            sd = 0
        if sd > 0:
            cand = [i for i in range(n) if abs(resid[i]) > z * sd]
            max_rm = min(len(cand), int(n * max_frac), n - 6)
            if max_rm > 0:
                for i in sorted(cand, key=lambda i: abs(resid[i]), reverse=True)[:max_rm]:
                    flags[i] = True
    clean = [pairs[i] for i in range(n) if not flags[i]]
    cx = [p[0] for p in clean]
    cy = [p[1] for p in clean]
    # RMSE of the clean fit residuals (the "mean error" + the ±band half-width)
    rmse = None
    cfit = linear_trend(cx, cy)
    if cfit and len(cx) >= 2:
        cs, ci = cfit
        res2 = [cy[i] - (cs * cx[i] + ci) for i in range(len(cx))]
        rmse = round((sum(e * e for e in res2) / len(res2)) ** 0.5, 3)
    return {
        "points": pairs,
        "outliers": flags,
        "r": pearson(cx, cy),
        "r_all": pearson(fx, fy),
        "line": regression_endpoints(cx, cy),
        "rmse": rmse,
        "n": len(clean),
        "removed": sum(flags),
    }


# --- p-value machinery: regularized incomplete beta -> Student-t & F tails ---
def _betacf(a, b, x):
    """Continued fraction for the incomplete beta (Numerical Recipes)."""
    MAXIT, EPS, FPMIN = 300, 1e-14, 1e-300
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c = 1.0
    d = 1.0 - qab * x / qap
    if abs(d) < FPMIN:
        d = FPMIN
    d = 1.0 / d
    h = d
    for m in range(1, MAXIT + 1):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        if abs(d) < FPMIN:
            d = FPMIN
        c = 1.0 + aa / c
        if abs(c) < FPMIN:
            c = FPMIN
        d = 1.0 / d
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        if abs(d) < FPMIN:
            d = FPMIN
        c = 1.0 + aa / c
        if abs(c) < FPMIN:
            c = FPMIN
        d = 1.0 / d
        de = d * c
        h *= de
        if abs(de - 1.0) < EPS:
            break
    return h


def _betai(a, b, x):
    """Regularized incomplete beta I_x(a, b)."""
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    lbt = (math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
           + a * math.log(x) + b * math.log(1.0 - x))
    bt = math.exp(lbt)
    if x < (a + 1.0) / (a + b + 2.0):
        return bt * _betacf(a, b, x) / a
    return 1.0 - bt * _betacf(b, a, 1.0 - x) / b


def _t_p_two(t, df):
    """Two-sided p-value for a Student-t statistic with df degrees of freedom."""
    if df <= 0:
        return None
    return _betai(df / 2.0, 0.5, df / (df + t * t))


def _f_p(F, d1, d2):
    """Upper-tail p-value for an F(d1, d2) statistic."""
    if F is None or F <= 0 or d1 <= 0 or d2 <= 0:
        return None
    return _betai(d2 / 2.0, d1 / 2.0, d2 / (d2 + d1 * F))


def _mat_solve(A, b):
    """Solve the square system A x = b by Gauss-Jordan with partial pivoting."""
    n = len(A)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for col in range(n):
        piv = max(range(col, n), key=lambda r: abs(M[r][col]))
        if abs(M[piv][col]) < 1e-15:
            return None
        M[col], M[piv] = M[piv], M[col]
        pv = M[col][col]
        M[col] = [v / pv for v in M[col]]
        for r in range(n):
            if r != col and M[r][col] != 0:
                f = M[r][col]
                M[r] = [M[r][k] - f * M[col][k] for k in range(n + 1)]
    return [M[i][n] for i in range(n)]


def _mat_inv(A):
    """Inverse of a square matrix (solve against each unit column)."""
    n = len(A)
    cols = []
    for j in range(n):
        e = [1.0 if i == j else 0.0 for i in range(n)]
        s = _mat_solve(A, e)
        if s is None:
            return None
        cols.append(s)
    return [[cols[j][i] for j in range(n)] for i in range(n)]


def ols(y, xcols):
    """OLS y ~ 1 + x1 + … + xk with full inference, pure stdlib.

    Returns per-model R²/adjusted-R²/RMSE and, crucially, the overall-model
    F p-value plus each coefficient's two-sided t p-value — so significance is
    visible rather than assumed. ``xcols`` is a list of k predictor columns.
    """
    k = len(xcols)
    idx = [i for i in range(len(y))
           if _ok(y[i]) and all(i < len(c) and _ok(c[i]) for c in xcols)]
    n = len(idx)
    if n < k + 3:                       # need residual degrees of freedom
        return None
    Y = [y[i] for i in idx]
    p = k + 1
    X = [[1.0] + [xcols[j][i] for j in range(k)] for i in idx]
    XtX = [[sum(X[r][a] * X[r][c] for r in range(n)) for c in range(p)] for a in range(p)]
    Xty = [sum(X[r][a] * Y[r] for r in range(n)) for a in range(p)]
    beta = _mat_solve(XtX, Xty)
    if beta is None:
        return None
    pred = [sum(beta[a] * X[r][a] for a in range(p)) for r in range(n)]
    ss_res = sum((Y[r] - pred[r]) ** 2 for r in range(n))
    ybar = sum(Y) / n
    ss_tot = sum((v - ybar) ** 2 for v in Y)
    if ss_tot <= 0:
        return None
    r2 = 1 - ss_res / ss_tot
    dfres = n - p
    adj = 1 - (1 - r2) * (n - 1) / dfres if dfres > 0 else None
    F = (r2 / k) / ((1 - r2) / dfres) if (dfres > 0 and r2 < 1) else None
    p_model = _f_p(F, k, dfres)
    mse = ss_res / dfres if dfres > 0 else None
    inv = _mat_inv(XtX)
    p_coef = [None] * p
    if inv and mse and mse > 0:
        for a in range(p):
            var = mse * inv[a][a]
            if var > 0:
                p_coef[a] = _t_p_two(beta[a] / var ** 0.5, dfres)
    return {"beta": beta, "r2": r2, "adj_r2": adj, "rmse": (ss_res / n) ** 0.5,
            "n": n, "k": k, "f": F, "p_model": p_model, "p_coef": p_coef}


def multi_regress(y, x1, x2):
    """OLS y = b0 + b1·x1 + b2·x2 with inference. Returns coefficients, R²,
    adjusted R², RMSE, the model F p-value and each slope's p-value — or None."""
    res = ols(y, [x1, x2])
    if not res:
        return None
    b0, b1, b2 = res["beta"]
    return {"b0": round(b0, 3), "b1": round(b1, 4), "b2": round(b2, 4),
            "r2": round(res["r2"], 3),
            "adj_r2": round(res["adj_r2"], 3) if res["adj_r2"] is not None else None,
            "rmse": round(res["rmse"], 2), "n": res["n"],
            "f": round(res["f"], 2) if res["f"] else None,
            "p_model": res["p_model"], "p_b1": res["p_coef"][1], "p_b2": res["p_coef"][2]}


def safe_stats(values):
    """min/median/max of a list ignoring None; returns (min, median, max) or Nones."""
    vals = [v for v in values if _ok(v)]
    if not vals:
        return (None, None, None)
    return (round(min(vals), 2), round(statistics.median(vals), 2), round(max(vals), 2))
