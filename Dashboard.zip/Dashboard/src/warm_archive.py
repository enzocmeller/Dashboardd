"""Patiently warm the Open-Meteo ARCHIVE cache (climate normals, GDD normal,
season-temperature, monthly climate) for every state's corn point + the national
centroid.

The archive endpoint rate-limits (HTTP 429) under bursty load, which leaves a run
carrying over last-good weather instead of computing it fresh. This fetches every
archive-backed value the pipeline needs, one at a time with a polite delay and a
long wait-and-retry on 429, so the cache ends up complete. It is idempotent (the
underlying openmeteo functions skip anything already cached), so it can be run
repeatedly and picks up where it left off. Run it, then run `python src/update.py`
for a clean, fully-fresh build.

    python src/warm_archive.py
"""
import datetime
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cache
import config
import http_util
from sources import openmeteo


def _try(fn, label, tries=6):
    """Call fn(); on a rate-limit/circuit-breaker error, wait and retry."""
    for attempt in range(tries):
        http_util._blocked_hosts.clear()  # don't fail-fast on a prior cooldown
        try:
            fn()
            return True
        except http_util.HttpError as exc:
            if exc.status == 429:
                wait = min(180, 20 * (attempt + 1))
                print(f"    429 on {label}; waiting {wait}s (attempt {attempt+1}/{tries})", flush=True)
                time.sleep(wait)
                continue
            print(f"    ! {label}: {exc}", flush=True)
            return False
        except Exception as exc:
            print(f"    ! {label}: {exc}", flush=True)
            return False
    return False


def _regression_year0(cfg, dev):
    resid = {yr: rv for yr, rv in zip((dev or {}).get("years", []), (dev or {}).get("residuals", []))
             if rv is not None}
    if not resid:
        return None
    return max(int(cfg.get("regression_start_year", 2008)), min(resid))


def warm_point(cfg, lat, lon, today, dev):
    """Warm every archive-backed value the pipeline computes at (lat, lon)."""
    ok = 0
    ok += _try(lambda: openmeteo.normals(lat, lon), "normals")
    ok += _try(lambda: openmeteo.gdd_normal(lat, lon), "gdd_normal")
    y0 = _regression_year0(cfg, dev)
    if y0 is not None:
        ok += _try(lambda: openmeteo.season_temp_by_year(lat, lon, y0, today.year - 1), f"season_temp {y0}-{today.year-1}")
    # monthly climate needs the (now-cached) normals; best-effort
    try:
        norm = openmeteo.normals(lat, lon)
        _try(lambda: openmeteo.monthly_climate(lat, lon, today.year, today, norm), "climate")
        ok += 1
    except Exception:
        pass
    return ok


def main():
    cfg = config.load()
    http_util.configure(ca_bundle=cfg["ca_bundle"], delay=max(1.0, float(cfg["request_delay_seconds"])),
                        timeout=cfg["request_timeout_seconds"], retries=2)
    cache.init(cfg["data_dir"])
    today = datetime.date.today()

    data_path = os.path.join(cfg["data_dir"], "dashboard_data.json")
    payload = json.load(open(data_path, encoding="utf-8")) if os.path.exists(data_path) else {"states": {}}
    states = payload.get("states", {})

    # per-state corn points
    pts = []
    for us, s in states.items():
        if us == "US":
            continue
        p = s.get("corn_point")
        if p:
            pts.append((us, p["lat"], p["lon"], s.get("yield_deviation")))

    # national production-weighted centroid (same formula as national_aggregates)
    ranking = (payload.get("production") or {}).get("ranking") or []
    weights = {r["usps"]: r["bu"] for r in ranking if r.get("bu")}
    wpts = [(states[u]["corn_point"], weights[u]) for u in weights
            if states.get(u) and states[u].get("corn_point")]
    if wpts:
        tw = sum(w for _p, w in wpts)
        clat = sum(p["lat"] * w for p, w in wpts) / tw
        clon = sum(p["lon"] * w for p, w in wpts) / tw
        pts.append(("US-centroid", clat, clon, (states.get("US") or {}).get("yield_deviation")))

    print(f"warming archive cache for {len(pts)} points", flush=True)
    done = 0
    for i, (us, lat, lon, dev) in enumerate(pts, 1):
        print(f"[{i}/{len(pts)}] {us} ({lat:.2f},{lon:.2f})", flush=True)
        warm_point(cfg, lat, lon, today, dev)
        done += 1
    # ship a consolidated copy
    cache.export(os.path.join(cfg["data_dir"], "cache.sqlite"))
    print(f"done: warmed {done} points; exported data/cache.sqlite", flush=True)


if __name__ == "__main__":
    main()
