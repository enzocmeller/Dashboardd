"""A tiny SQLite key/value cache (standard library ``sqlite3``).

Used to make re-runs fast and polite:
- *Immutable* data (ERA5 climate normals, past GLAM composites, GLAM id maps)
  is fetched once and kept forever.
- *Volatile* data (current crop progress/condition, the latest forecast) is not
  cached and is re-fetched on every run, which is what makes the dashboard
  "auto-update every time you run it".
"""
import hashlib
import json
import os
import sqlite3
import tempfile
import time

_conn = None


def _cache_path(data_dir):
    """Local (non-cloud-synced) path for the sqlite cache.

    A live sqlite file inside a OneDrive/Dropbox-synced folder gets corrupted when
    the sync client copies it mid-write ("database disk image is malformed"), which
    silently disables caching and forces every run to re-fetch everything. Keeping
    the cache in the local temp dir (keyed by project) avoids that entirely, while
    the JSON snapshot/deliverable still lives in the project folder.
    """
    tag = hashlib.md5(os.path.abspath(data_dir).encode("utf-8")).hexdigest()[:12]
    local = os.path.join(tempfile.gettempdir(), "corn_dashboard_cache")
    try:
        os.makedirs(local, exist_ok=True)
        return os.path.join(local, f"cache_{tag}.sqlite")
    except OSError:
        return os.path.join(data_dir, "cache.sqlite")  # fallback


def _open(path):
    conn = sqlite3.connect(path, timeout=10)
    conn.execute("PRAGMA journal_mode=WAL")     # safer concurrent + crash behavior
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=10000")
    conn.execute(
        "CREATE TABLE IF NOT EXISTS kv ("
        "  k TEXT PRIMARY KEY,"
        "  v TEXT NOT NULL,"
        "  created REAL NOT NULL"
        ")"
    )
    conn.commit()
    # prove the DB actually accepts writes (catches a malformed image up front)
    conn.execute("INSERT OR REPLACE INTO kv (k, v, created) VALUES ('__ok__', '1', ?)",
                 (time.time(),))
    conn.commit()
    return conn


def init(data_dir):
    global _conn
    os.makedirs(data_dir, exist_ok=True)
    path = _cache_path(data_dir)
    try:
        _conn = _open(path)
    except sqlite3.Error:
        # corrupt/unusable cache: rebuild it from scratch rather than run cacheless
        try:
            for ext in ("", "-wal", "-shm"):
                if os.path.exists(path + ext):
                    os.remove(path + ext)
            _conn = _open(path)
        except (sqlite3.Error, OSError):
            _conn = None  # last resort: run without a cache rather than crash
    # First run on this machine: bootstrap from the shipped pre-fetched cache so the
    # slow historical NDVI/normals aren't re-downloaded (turns a ~2 h cold run into
    # minutes). Runs ONCE per local cache; live USDA/forecast data is never cached, so
    # this only reuses immutable history and never serves stale current numbers.
    if _conn is not None and get("__seeded__") is None:
        _seed_from_shipped(data_dir)
        set("__seeded__", "1")
    return _conn


def _seed_from_shipped(data_dir):
    """Import the project's shipped data/cache.sqlite (pre-fetched immutable NDVI
    composites + ERA5 climate normals) into the fresh local cache. INSERT OR IGNORE
    never clobbers anything already cached this run."""
    if _conn is None:
        return
    shipped = os.path.join(data_dir, "cache.sqlite")
    if not os.path.exists(shipped) or os.path.abspath(shipped) == os.path.abspath(_cache_path(data_dir)):
        return
    try:
        src = sqlite3.connect(shipped, timeout=10)
        rows = src.execute("SELECT k, v, created FROM kv").fetchall()
        src.close()
        useful = [r for r in rows if not str(r[0]).startswith("__") and r[0] != "test"]
        if useful:
            _conn.executemany("INSERT OR IGNORE INTO kv (k, v, created) VALUES (?, ?, ?)", useful)
            _conn.commit()
    except sqlite3.Error:
        pass


def get(key):
    if _conn is None:
        return None
    try:
        row = _conn.execute("SELECT v FROM kv WHERE k = ?", (key,)).fetchone()
    except sqlite3.Error:
        return None
    return row[0] if row else None


def set(key, value):
    if _conn is None:
        return
    try:
        _conn.execute(
            "INSERT OR REPLACE INTO kv (k, v, created) VALUES (?, ?, ?)",
            (key, value, time.time()),
        )
        _conn.commit()
    except sqlite3.Error:
        pass  # a locked/corrupt cache must never break the run


def get_json(key):
    raw = get(key)
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return None


def set_json(key, obj):
    set(key, json.dumps(obj))


def export(dest_path):
    """Write a clean single-file copy of the cache to ``dest_path`` (for shipping).

    The live cache lives in local temp (off cloud-synced folders), but the design
    ships a warm cache so the firewalled work machine can regenerate offline. This
    uses the sqlite backup API, so it produces a consolidated file even in WAL mode.
    """
    if _conn is None:
        return False
    try:
        dst = sqlite3.connect(dest_path)
        with dst:
            _conn.backup(dst)
        dst.close()
        return True
    except (sqlite3.Error, OSError):
        return False


def cached_json(key, producer):
    """Return cached JSON for ``key`` or call ``producer()``, cache, and return it."""
    hit = get_json(key)
    if hit is not None:
        return hit
    value = producer()
    if value is not None:
        set_json(key, value)
    return value
