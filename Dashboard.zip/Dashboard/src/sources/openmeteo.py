"""Open-Meteo client: 16-day forecast, soil moisture, ERA5 climate normals, and
forecast-vs-normal anomalies on the 1-5 / 6-10 / 11-15 / 1-15 day windows.

No API key (non-commercial/free). HTTPS/443 JSON. Standard library only.
ERA5 normals are immutable, so they are cached permanently per location.
"""
import datetime
import urllib.parse

import cache
import http_util

FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
ARCHIVE_URL = "https://archive-api.open-meteo.com/v1/archive"

# root-zone soil-moisture layers (cm) and their thickness weights
_SM_LAYERS = [
    ("soil_moisture_0_to_1cm", 1),
    ("soil_moisture_1_to_3cm", 2),
    ("soil_moisture_3_to_9cm", 6),
    ("soil_moisture_9_to_27cm", 18),
]


def _url(base, params):
    return base + "?" + urllib.parse.urlencode(params, quote_via=urllib.parse.quote)


def fetch_forecast(lat, lon):
    """One call returns the daily temp/precip forecast + hourly soil moisture."""
    params = {
        "latitude": f"{lat:.4f}",
        "longitude": f"{lon:.4f}",
        "daily": "temperature_2m_mean,precipitation_sum",
        "hourly": ",".join(name for name, _w in _SM_LAYERS),
        "forecast_days": "16",
        "timezone": "auto",
    }
    return http_util.get_json(_url(FORECAST_URL, params))


# --- soil moisture by model (European ECMWF + Canadian GEM); GFS has none ---
# Root-zone layers, thickness-weighted: the 0-7 cm SURFACE is volatile and dries out
# between rains (it read ~20% "Poor" for wet-profile Illinois), so we use the crop's
# actual water-supply zone (~0-28/0-35 cm) instead. (layer_var, thickness_cm)
SOIL_MODELS = [
    # ECMWF exposes a real root zone (0-28 cm) -> the representative headline + grade.
    ("ECMWF", "ecmwf_ifs025",
     [("soil_moisture_0_to_7cm", 7), ("soil_moisture_7_to_28cm", 21)], "0–28 cm"),
    # GEM only publishes its 0-10 cm surface layer -> shown as a second (shallower) read.
    ("GEM", "gem_seamless",
     [("soil_moisture_0_to_10cm", 10)], "0–10 cm"),
]
# volumetric-% V/P/F/G/E thresholds (soil-agnostic; configurable)
_SOIL_GRADE = [(15, "V"), (22, "P"), (30, "F"), (38, "G")]


def soil_grade(pct):
    if pct is None:
        return None
    for thr, g in _SOIL_GRADE:
        if pct < thr:
            return g
    return "E"


def soil_models(lat, lon):
    """Root-zone volumetric soil-moisture % (today and +10 day) from ECMWF + GEM,
    thickness-weighted over the crop's water-supply zone, with a V/P/F/G/E grade."""
    out = []
    for name, model, layers, label in SOIL_MODELS:
        variables = ",".join(v for v, _t in layers)
        params = {"latitude": f"{lat:.4f}", "longitude": f"{lon:.4f}", "hourly": variables,
                  "models": model, "forecast_days": "11", "timezone": "auto"}
        try:
            data = http_util.get_json(_url(FORECAST_URL, params))
        except Exception:
            continue
        hourly = data.get("hourly") or {}
        times = hourly.get("time") or []
        totth = sum(t for _v, t in layers)
        by_day = {}
        for i, t in enumerate(times):
            num, ok = 0.0, True
            for var, th in layers:
                arr = hourly.get(var) or []
                v = arr[i] if i < len(arr) else None
                if v is None:
                    ok = False
                    break
                num += v * th
            if ok:
                by_day.setdefault(t[:10], []).append(num / totth)  # thickness-weighted volumetric
        days = sorted(by_day)
        if not days:
            continue

        def dpct(d):
            a = by_day.get(d) or []
            return round(sum(a) / len(a) * 100, 1) if a else None

        today_pct = dpct(days[0])
        # ~0 volumetric moisture is physically implausible for real soil -> masked/
        # invalid pixel (e.g. a non-corn point over water); drop that model entirely.
        if today_pct is None or today_pct < 1.0:
            continue
        out.append({"model": name, "layer": label,
                    "today": today_pct, "day10": dpct(days[min(10, len(days) - 1)])})
    if not out:
        return None
    primary = out[0]["today"]
    return {"models": out, "current_pct": primary, "grade": soil_grade(primary), "unit": "% vol"}


def forecast_model(lat, lon, model):
    """Daily temp/precip 15-day forecast for one model (gfs_seamless / ecmwf_ifs025)."""
    params = {"latitude": f"{lat:.4f}", "longitude": f"{lon:.4f}",
              "daily": "temperature_2m_mean,precipitation_sum", "models": model,
              "forecast_days": "15", "timezone": "auto"}
    return http_util.get_json(_url(FORECAST_URL, params))


def soil_moisture(forecast):
    """Daily root-zone (0-27 cm) volumetric soil moisture from the forecast."""
    hourly = forecast.get("hourly") or {}
    times = hourly.get("time") or []
    if not times:
        return None
    # accumulate per-day weighted sums
    day_acc = {}   # date -> [weighted_sum, weight_count]
    weights_total = sum(w for _n, w in _SM_LAYERS)
    per_hour = []
    for i, t in enumerate(times):
        num = 0.0
        wsum = 0
        for name, w in _SM_LAYERS:
            arr = hourly.get(name)
            if not arr or i >= len(arr) or arr[i] is None:
                continue
            num += arr[i] * w
            wsum += w
        if wsum == 0:
            continue
        val = num / wsum
        per_hour.append((t, val))
    for t, val in per_hour:
        d = t[:10]
        acc = day_acc.setdefault(d, [0.0, 0])
        acc[0] += val
        acc[1] += 1
    dates = sorted(day_acc)
    values = [round(day_acc[d][0] / day_acc[d][1], 3) for d in dates]
    if not values:
        return None
    # an all-~0 series means no soil grid over this point (e.g. a small island corn
    # point like Hawaii) -> report no data rather than a flat 0.0 line.
    if max(values) < 0.001:
        return None
    return {
        "current": values[0],
        "dates": [d[5:] for d in dates],
        "values": values,
        "unit": "m³/m³",
    }


def _doy(date_str):
    return datetime.date.fromisoformat(date_str).timetuple().tm_yday


def _doy_climatology(daily, fields):
    """Build smoothed (±7 day) per-DOY normals for the requested daily fields."""
    times = daily.get("time") or []
    buckets = {f: [[] for _ in range(367)] for f in fields}
    for i, t in enumerate(times):
        try:
            d = _doy(t)
        except (ValueError, TypeError):
            continue
        for f in fields:
            arr = daily.get(f) or []
            if i < len(arr) and arr[i] is not None:
                buckets[f][d].append(arr[i])

    def base(lists):
        return [None if not lists[d] else sum(lists[d]) / len(lists[d]) for d in range(367)]

    def smooth(arr):
        out = [None] * 367
        for d in range(1, 367):
            win = [arr[((k - 1) % 366) + 1] for k in range(d - 7, d + 8)
                   if arr[((k - 1) % 366) + 1] is not None]
            out[d] = round(sum(win) / len(win), 3) if win else None
        return out

    return {f: smooth(base(buckets[f])) for f in fields}


def normals(lat, lon):
    """Smoothed day-of-year ERA5 1991-2020 normals (temp mean, precip). Cached forever."""
    key = f"normals:{round(lat, 2)}:{round(lon, 2)}"
    cached = cache.get_json(key)
    if cached is not None:
        return cached
    params = {
        "latitude": f"{lat:.4f}",
        "longitude": f"{lon:.4f}",
        "start_date": "1991-01-01",
        "end_date": "2020-12-31",
        "daily": "temperature_2m_mean,precipitation_sum",
        "timezone": "auto",
    }
    data = http_util.get_json(_url(ARCHIVE_URL, params))
    daily = data.get("daily") or {}
    clim = _doy_climatology(daily, ["temperature_2m_mean", "precipitation_sum"])
    result = {"temp": clim["temperature_2m_mean"], "precip": clim["precipitation_sum"]}
    if daily.get("time"):  # never freeze an empty/degraded archive response under this immutable key
        cache.set_json(key, result)
    return result


def gdd_f(tmax_c, tmin_c):
    """Daily corn growing-degree-days (base 50 °F, cap 86 °F) from °C max/min."""
    if tmax_c is None or tmin_c is None:
        return 0.0
    tmax = min(tmax_c * 9 / 5 + 32, 86.0)
    tmin = max(tmin_c * 9 / 5 + 32, 50.0)
    return max(0.0, (tmax + tmin) / 2.0 - 50.0)


def gdd_normal(lat, lon):
    """Per-DOY GDD normal from a 10-year ERA5 window (lighter archive call). Cached.

    CRUCIAL: the normal must be the mean of each day's GDD, NOT the GDD computed
    from day-of-year-mean temperatures. The 50 °F floor / 86 °F cap make
    gdd(mean_T) < mean(gdd(T)) in the shoulder seasons (Jensen's inequality), so
    the old temp-first approach biased the normal LOW and made every year read
    above-normal. We compute daily GDD first, then average per day-of-year.
    """
    key = f"gddnorm2:{round(lat, 2)}:{round(lon, 2)}"   # v2: daily-GDD-then-average
    cached = cache.get_json(key)
    if cached is not None:
        return cached
    params = {
        "latitude": f"{lat:.4f}",
        "longitude": f"{lon:.4f}",
        "start_date": "2011-01-01",
        "end_date": "2020-12-31",
        "daily": "temperature_2m_max,temperature_2m_min",
        "timezone": "auto",
    }
    data = http_util.get_json(_url(ARCHIVE_URL, params))
    daily = data.get("daily") or {}
    times = daily.get("time") or []
    tmax = daily.get("temperature_2m_max") or []
    tmin = daily.get("temperature_2m_min") or []
    gdaily = [gdd_f(tmax[i] if i < len(tmax) else None,
                    tmin[i] if i < len(tmin) else None) for i in range(len(times))]
    clim = _doy_climatology({"time": times, "gdd_daily": gdaily}, ["gdd_daily"])
    smoothed = clim["gdd_daily"]
    gdd = [round(smoothed[d], 2) if smoothed[d] is not None else 0.0 for d in range(367)]
    if times:  # don't freeze an empty archive response forever
        cache.set_json(key, gdd)
    return gdd


def gdd_by_year(lat, lon, y0, y1, start_month):
    """Cumulative corn GDD by date for each year in [y0, y1], from ``start_month``.

    One ERA5 archive call for the whole span; accumulation resets each year at
    ``start_month``. Returns {"dates": [MM-DD...], "years": {str(y): [cum...]}}
    aligned on a shared MM-DD grid, or None. Historical -> cached permanently.
    """
    key = f"gddyr:{round(lat, 2)}:{round(lon, 2)}:{y0}:{y1}:{start_month}"
    cached = cache.get_json(key)
    if cached is not None:
        return cached
    params = {"latitude": f"{lat:.4f}", "longitude": f"{lon:.4f}",
              "start_date": f"{y0}-{start_month:02d}-01", "end_date": f"{y1}-12-31",
              "daily": "temperature_2m_max,temperature_2m_min", "timezone": "auto"}
    data = http_util.get_json(_url(ARCHIVE_URL, params))
    daily = data.get("daily") or {}
    times = daily.get("time") or []
    tmax = daily.get("temperature_2m_max") or []
    tmin = daily.get("temperature_2m_min") or []
    if not times:
        return None
    per_year, acc = {}, {}
    for i, t in enumerate(times):
        try:
            d = datetime.date.fromisoformat(t)
        except (ValueError, TypeError):
            continue
        if d.month < start_month:  # season only, from start_month onward
            continue
        g = gdd_f(tmax[i] if i < len(tmax) else None, tmin[i] if i < len(tmin) else None)
        acc[d.year] = acc.get(d.year, 0.0) + g
        if d.month != 2 or d.day != 29:  # drop Feb-29 so years align on a common MM-DD grid
            per_year.setdefault(d.year, {})[t[5:]] = round(acc[d.year])
    if not per_year:
        return None
    all_dates = sorted({md for yd in per_year.values() for md in yd})
    result = {"dates": all_dates,
              "years": {str(y): [per_year[y].get(md) for md in all_dates] for y in sorted(per_year)}}
    cache.set_json(key, result)
    return result


def gdd_series(lat, lon, start_date, end_date):
    """Cumulative GDD (actual vs normal) from start_date to today.

    Actual comes from the FORECAST endpoint via past_days (avoids the heavily
    rate-limited archive endpoint); the normal is the cached gdd_normal.
    """
    key = f"gdd:{round(lat, 2)}:{round(lon, 2)}:{start_date}:{end_date}"
    cached = cache.get_json(key)
    if cached is not None:
        return cached

    start = datetime.date.fromisoformat(start_date)
    end = datetime.date.fromisoformat(end_date)
    full_past = (end - start).days
    if full_past < 1:
        return None

    # The normal needs the (rate-limited) archive; if it's unavailable we still
    # show actual accumulation and fill the normal in on a later run.
    try:
        gnorm = gdd_normal(lat, lon)
    except Exception:
        gnorm = None

    base = {"latitude": f"{lat:.4f}", "longitude": f"{lon:.4f}",
            "daily": "temperature_2m_max,temperature_2m_min", "timezone": "auto"}
    if full_past <= 92:
        # forecast endpoint covers the whole season (avoids the rate-limited
        # archive) and includes today
        params = dict(base, past_days=str(full_past), forecast_days="1")
        data = http_util.get_json(_url(FORECAST_URL, params))
    else:
        # season longer than the 92-day forecast window -> archive the full range
        # so cumulative GDD is not silently truncated late in the season
        params = dict(base, start_date=start_date, end_date=end_date)
        data = http_util.get_json(_url(ARCHIVE_URL, params))
    daily = data.get("daily") or {}
    times = daily.get("time") or []
    tmax = daily.get("temperature_2m_max") or []
    tmin = daily.get("temperature_2m_min") or []

    dates, actual_cum, normal_cum = [], [], []
    acc = nacc = 0.0
    for i, t in enumerate(times):
        if t > end_date:
            break  # actual only up to today
        if i >= len(tmax) or i >= len(tmin) or tmax[i] is None or tmin[i] is None:
            continue
        acc += gdd_f(tmax[i], tmin[i])
        dates.append(t)
        actual_cum.append(round(acc))
        if gnorm:
            try:
                nacc += gnorm[_doy(t)] or 0.0
            except (ValueError, IndexError, TypeError):
                pass
            normal_cum.append(round(nacc))
        else:
            normal_cum.append(None)

    if not dates:
        return None
    td = actual_cum[-1]
    ntd = normal_cum[-1] if gnorm else None
    result = {
        "dates": [d[5:] for d in dates],
        "actual_cum": actual_cum,
        "normal_cum": normal_cum,
        "to_date": td,
        "normal_to_date": ntd,
        "pct_of_normal": round(td / ntd * 100) if ntd else None,
        "through": dates[-1],
    }
    # Cache permanently ONLY when the series is complete: it has the normal AND
    # actually begins at the labeled season start (never freeze a truncated or
    # normal-less result — a later run can then fix it).
    if gnorm and dates[0] <= start_date:
        cache.set_json(key, result)
    return result


_MONTH_NAMES = {1: "Jan", 2: "Feb", 3: "Mar", 4: "Apr", 5: "May", 6: "Jun",
                7: "Jul", 8: "Aug", 9: "Sep", 10: "Oct", 11: "Nov", 12: "Dec"}


def season_temp_by_year(lat, lon, y0, y1, months=(7, 8)):
    """Mean 2 m temperature over ``months`` for each year in [y0, y1].

    One archive call for the whole span (historical -> cached permanently); used
    as the temperature predictor in the multiple-regression panel.
    """
    mtag = "-".join(str(m) for m in months)
    key = f"seastemp:{round(lat, 2)}:{round(lon, 2)}:{y0}:{y1}:{mtag}"
    cached = cache.get_json(key)
    if cached is not None:
        return {int(k): v for k, v in cached.items()}
    params = {"latitude": f"{lat:.4f}", "longitude": f"{lon:.4f}",
              "start_date": f"{y0}-01-01", "end_date": f"{y1}-12-31",
              "daily": "temperature_2m_mean", "timezone": "auto"}
    data = http_util.get_json(_url(ARCHIVE_URL, params))
    daily = data.get("daily") or {}
    times = daily.get("time") or []
    temps = daily.get("temperature_2m_mean") or []
    acc = {}
    for t, v in zip(times, temps):
        if v is None:
            continue
        try:
            d = datetime.date.fromisoformat(t)
        except (ValueError, TypeError):
            continue
        if d.month in months:
            acc.setdefault(d.year, []).append(v)
    out = {y: round(sum(vs) / len(vs), 2) for y, vs in acc.items() if vs}
    if out:  # don't cache an empty (rate-limited/degraded) result
        cache.set_json(key, {str(k): v for k, v in out.items()})
    return out


def season_precip_by_year(lat, lon, y0, y1, months=(6, 7, 8)):
    """Total precipitation (mm) over ``months`` for each year in [y0, y1].

    One archive call for the whole span (cached permanently); the summer-rainfall
    predictor candidate for the multiple-regression panel (grain-fill moisture).
    """
    mtag = "-".join(str(m) for m in months)
    key = f"seasprecip:{round(lat, 2)}:{round(lon, 2)}:{y0}:{y1}:{mtag}"
    cached = cache.get_json(key)
    if cached is not None:
        return {int(k): v for k, v in cached.items()}
    params = {"latitude": f"{lat:.4f}", "longitude": f"{lon:.4f}",
              "start_date": f"{y0}-01-01", "end_date": f"{y1}-12-31",
              "daily": "precipitation_sum", "timezone": "auto"}
    data = http_util.get_json(_url(ARCHIVE_URL, params))
    daily = data.get("daily") or {}
    times = daily.get("time") or []
    precip = daily.get("precipitation_sum") or []
    acc = {}
    for t, v in zip(times, precip):
        if v is None:
            continue
        try:
            d = datetime.date.fromisoformat(t)
        except (ValueError, TypeError):
            continue
        if d.month in months:
            acc.setdefault(d.year, []).append(v)
    out = {y: round(sum(vs), 1) for y, vs in acc.items() if vs}
    if out:  # don't cache an empty (rate-limited/degraded) result
        cache.set_json(key, {str(k): v for k, v in out.items()})
    return out


def _normal_month(norm, months):
    """Aggregate per-DOY normals into {month: (precip_total, temp_mean)}."""
    out = {}
    if not norm:
        return out
    tarr = norm.get("temp") or []
    parr = norm.get("precip") or []
    for m in months:
        tv, pv, phas = [], 0.0, False
        for day in range(1, 32):
            try:
                doy = datetime.date(2021, m, day).timetuple().tm_yday  # 2021 = non-leap
            except ValueError:
                break
            if doy < len(tarr) and tarr[doy] is not None:
                tv.append(tarr[doy])
            if doy < len(parr) and parr[doy] is not None:
                pv += parr[doy]
                phas = True
        out[m] = (round(pv, 1) if phas else None,
                  round(sum(tv) / len(tv), 1) if tv else None)
    return out


def monthly_climate(lat, lon, year, today, norm, months=(6, 7, 8, 9)):
    """Observed monthly precip total + mean temp for ``year`` vs the 1991-2020
    normal (item 16). One archive call for the season-to-date, cached by end date
    so it refreshes as months fill in."""
    end = today.isoformat() if hasattr(today, "isoformat") else str(today)
    obs_p, obs_t = {}, {}
    key = f"climobs:{round(lat, 2)}:{round(lon, 2)}:{year}:{end}"
    cached = cache.get_json(key)
    if cached is not None:
        obs_p = {int(k): v for k, v in cached["p"].items()}
        obs_t = {int(k): v for k, v in cached["t"].items()}
    else:
        params = {"latitude": f"{lat:.4f}", "longitude": f"{lon:.4f}",
                  "start_date": f"{year}-{min(months):02d}-01", "end_date": end,
                  "daily": "temperature_2m_mean,precipitation_sum", "timezone": "auto"}
        data = http_util.get_json(_url(ARCHIVE_URL, params))
        daily = data.get("daily") or {}
        times = daily.get("time") or []
        tt = daily.get("temperature_2m_mean") or []
        pp = daily.get("precipitation_sum") or []
        pacc, tacc = {}, {}
        for i, ts in enumerate(times):
            try:
                d = datetime.date.fromisoformat(ts)
            except (ValueError, TypeError):
                continue
            if i < len(pp) and pp[i] is not None:
                pacc[d.month] = pacc.get(d.month, 0.0) + pp[i]
            if i < len(tt) and tt[i] is not None:
                tacc.setdefault(d.month, []).append(tt[i])
        obs_p = {m: round(v, 1) for m, v in pacc.items()}
        obs_t = {m: round(sum(v) / len(v), 1) for m, v in tacc.items() if v}
        if obs_p or obs_t:  # don't freeze an empty/partial archive result for the day
            cache.set_json(key, {"p": {str(k): v for k, v in obs_p.items()},
                                 "t": {str(k): v for k, v in obs_t.items()}})
    nmon = _normal_month(norm, months)
    rows = []
    for m in months:
        np_, nt_ = nmon.get(m, (None, None))
        rows.append({"month": _MONTH_NAMES.get(m, str(m)),
                     "precip": obs_p.get(m), "precip_normal": np_,
                     "temp": obs_t.get(m), "temp_normal": nt_})
    return {"year": year, "rows": rows}


def weather_anomaly(forecast, norm):
    """Forecast-minus-normal anomalies grouped into days 1-5 / 6-10 / 11-15 / 1-15."""
    daily = forecast.get("daily") or {}
    times = daily.get("time") or []
    temps = daily.get("temperature_2m_mean") or []
    precs = daily.get("precipitation_sum") or []
    if len(times) < 15 or not norm:
        return None

    windows = [(0, 5), (5, 10), (10, 15), (0, 15)]
    temp_out, precip_mm_out, precip_pct_out = [], [], []
    for start, end in windows:
        t_anoms, f_prec, n_prec = [], 0.0, 0.0
        for i in range(start, end):
            try:
                d = _doy(times[i])
            except (ValueError, IndexError, TypeError):
                continue
            tn = norm["temp"][d]
            pn = norm["precip"][d]
            if i < len(temps) and temps[i] is not None and tn is not None:
                t_anoms.append(temps[i] - tn)
            # sum forecast and normal precip over the SAME days, else the ratio is biased
            if i < len(precs) and precs[i] is not None and pn is not None:
                f_prec += precs[i]
                n_prec += pn
        temp_out.append(round(sum(t_anoms) / len(t_anoms), 2) if t_anoms else None)
        precip_mm_out.append(round(f_prec - n_prec, 1))
        precip_pct_out.append(round(f_prec / n_prec * 100, 0) if n_prec > 0 else None)

    return {
        "windows": ["1-5 d", "6-10 d", "11-15 d", "1-15 d"],
        "temp": temp_out,
        "precip_mm": precip_mm_out,
        "precip_pct": precip_pct_out,
    }
