"""Main entry point: gather all data for every state, then rebuild index.html.

Run:  python src/update.py
Re-running refreshes the live data and regenerates the dashboard.
"""
import datetime
import itertools
import json
import os
import sys
import time

# Fail clearly on old Python: statistics.linear_regression/correlation (used for the
# trend/correlation panels) are 3.10+, and the run would otherwise crash deep inside.
if sys.version_info < (3, 10):
    sys.exit("This tool requires Python 3.10+ (found %d.%d). Install a newer Python "
             "and re-run." % (sys.version_info[0], sys.version_info[1]))

# make sibling modules importable when run as a script
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import build
import cache
import config
import http_util
from compute import stats
from geo import corn_points
from sources import glam, nass, openmeteo
from states import BY_USPS, resolve


def _log(msg):
    print(msg, flush=True)


def _checkpoint_path(cfg):
    return os.path.join(cfg["data_dir"], "_build_checkpoint.json")


def _load_checkpoint(cfg, today):
    """Per-state results already built TODAY, so an interrupted run can resume."""
    try:
        with open(_checkpoint_path(cfg), encoding="utf-8") as fh:
            obj = json.load(fh)
        if obj.get("date") == today.isoformat():
            return obj.get("states") or {}
    except (OSError, ValueError):
        pass
    return {}


def _save_checkpoint(cfg, today, out):
    try:
        os.makedirs(cfg["data_dir"], exist_ok=True)
        tmp = _checkpoint_path(cfg) + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump({"date": today.isoformat(), "states": out}, fh, ensure_ascii=False)
        os.replace(tmp, _checkpoint_path(cfg))  # atomic: never leave a half-written file
    except OSError:
        pass


def _clear_checkpoint(cfg):
    try:
        os.remove(_checkpoint_path(cfg))
    except OSError:
        pass


def _load_prev(cfg):
    """Load the previous dashboard_data.json snapshot (or {} if none/unreadable)."""
    path = os.path.join(cfg["data_dir"], "dashboard_data.json")
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, json.JSONDecodeError):
        return {}


def _week_corr(gbwy, resid_by_year, target):
    """Correlate a single ISO week's G+E (across years, nearest week ±1) vs
    detrended yield. Returns the correlation_clean dict with per-point [year, week]
    labels attached, or None."""
    by_year = {}
    for w_s, yrs in (gbwy or {}).items():
        try:
            w = int(w_s)
        except (TypeError, ValueError):
            continue
        for y_s, ge in yrs.items():
            if ge is None:
                continue
            by_year.setdefault(int(y_s), {})[w] = ge
    xs, yv, labels = [], [], []
    for yr in sorted(by_year):
        if yr not in resid_by_year:
            continue
        wk_map = by_year[yr]
        best_w, best_d = None, 2
        for w in wk_map:
            d = abs(w - target)
            if d < best_d:
                best_w, best_d = w, d
        if best_w is None:
            continue
        xs.append(wk_map[best_w])
        yv.append(resid_by_year[yr])
        labels.append([yr, best_w])
    corr = stats.correlation_clean(xs, yv)
    if corr:
        corr["labels"] = labels
        corr["target_week"] = target
    return corr


def _finalize_regression(years, yv, x1, x2, yield_data, cy):
    """Shared: fit OLS, trim outlier years (|resid|>2σ, capped) & refit, then report
    single-var r's, a predicted-vs-actual scatter in bu/ac, and an expected cy yield."""
    import statistics as _st
    reg0 = stats.multi_regress(yv, x1, x2)
    if not reg0:
        return None
    b0, b1, b2 = reg0["b0"], reg0["b1"], reg0["b2"]
    err = [yv[i] - (b0 + b1 * x1[i] + b2 * x2[i]) for i in range(len(years))]
    try:
        sd = _st.pstdev(err)
    except _st.StatisticsError:
        sd = 0
    drop = set()
    if sd > 0:
        cand = [i for i in range(len(years)) if abs(err[i]) > 2.0 * sd]
        max_rm = min(len(cand), int(len(years) * 0.2), len(years) - 6)
        drop = set(sorted(cand, key=lambda i: abs(err[i]), reverse=True)[:max(0, max_rm)])
    keep = [i for i in range(len(years)) if i not in drop]
    ky = [years[i] for i in keep]
    kyv, kx1, kx2 = [yv[i] for i in keep], [x1[i] for i in keep], [x2[i] for i in keep]
    reg = stats.multi_regress(kyv, kx1, kx2) or reg0
    if reg is reg0:
        ky, kyv, kx1, kx2, drop = years, yv, x1, x2, set()
    reg["years"] = [ky[0], ky[-1]]
    reg["r_ndvi"] = stats.pearson(kx1, kyv)
    reg["r_temp"] = stats.pearson(kx2, kyv)
    reg["p_ndvi"] = reg.pop("p_b1", None)   # significance of each predictor
    reg["p_temp"] = reg.pop("p_b2", None)
    reg["removed"] = len(drop)
    reg["removed_years"] = sorted(years[i] for i in drop)
    # per-year predicted vs. actual converted back to actual yield (bu/ac)
    trend_by = {yr: t for yr, t in zip((yield_data or {}).get("years", []),
                                       (yield_data or {}).get("trend", []))}
    value_by = {yr: v for yr, v in zip((yield_data or {}).get("years", []),
                                       (yield_data or {}).get("values", []))}
    bb0, bb1, bb2 = reg["b0"], reg["b1"], reg["b2"]
    pyears, pactual, ppred = [], [], []
    for i, y in enumerate(ky):
        tr, av = trend_by.get(y), value_by.get(y)
        if tr is not None and av is not None:
            pyears.append(y)
            pactual.append(round(av, 1))
            ppred.append(round(tr + bb0 + bb1 * kx1[i] + bb2 * kx2[i], 1))
    reg["points"] = {"years": pyears, "actual": pactual, "predicted": ppred, "unit": "bu/ac"}
    # expected current-year yield = trend extrapolated to cy (mid-season NDVI/temp
    # predictors aren't in yet, so the model's central expectation is the trend value)
    _set_expected_yield(reg, yield_data, cy)
    return reg


def _yield_trend_r2(yield_data):
    """How well the linear yield~year trend fits (variance explained). Low = noisy,
    trendless yield history (small dryland states) where the extrapolated expected
    yield is unreliable and should be flagged low-confidence."""
    y = yield_data or {}
    vals, tr = y.get("values"), y.get("trend")
    if not vals or not tr or len(vals) != len(tr) or len(vals) < 3:
        return None
    m = sum(vals) / len(vals)
    sstot = sum((v - m) ** 2 for v in vals)
    if sstot <= 0:
        return None
    ssres = sum((v - t) ** 2 for v, t in zip(vals, tr))
    return round(1 - ssres / sstot, 3)


def _set_expected_yield(reg, yield_data, cy):
    """Attach the trend-based expected current-year yield + a confidence grade to a
    regression dict. Pure yield-trend math (no NDVI/temp, no network), so it's the
    reliable central estimate even when the 2-var model or a data source fails."""
    if reg is None:
        return
    ys = (yield_data or {}).get("years")
    tr = (yield_data or {}).get("trend")
    if not (ys and tr and len(ys) >= 2 and ys[-1] != ys[0]):
        return
    reg["expected_yield"] = round(tr[-1] + (tr[-1] - tr[0]) / (ys[-1] - ys[0]) * (cy - ys[-1]), 1)
    r2 = _yield_trend_r2(yield_data)
    reg["expected_yield_trend_r2"] = r2
    # noisy/trendless yield histories give an unreliable extrapolation (e.g. Montana's
    # 36-yr trend slopes DOWN because its small dryland acreage never gained yield).
    reg["expected_yield_conf"] = (
        "low" if r2 is None or r2 < 0.30 else "high" if r2 >= 0.50 else "medium")


def _ensure_expected_yield(out, cy):
    """Backstop after all fetches + carry-over: guarantee every state that has a yield
    trend carries a fresh trend-based expected_yield + confidence, even if its 2-var
    regression failed (archive throttled) or was carried in an older format missing
    the field. expected_yield is definitionally the trend value, so recomputing it
    centrally is always correct and immune to regression/source failures."""
    n = 0
    for st in out.values():
        yd = st.get("yield")
        if not yd or not yd.get("trend"):
            continue
        reg = st.get("regression")
        if reg is None:
            reg = {"trend_only": True}
        had = reg.get("expected_yield")
        _set_expected_yield(reg, yd, cy)
        if reg.get("expected_yield") is not None:
            st["regression"] = reg
            if had is None:
                n += 1
    if n:
        _log(f"  backfilled trend-based expected_yield for {n} states")


# ---------------------------------------------------------------------------
# Yield-driver regression — the MODEL FORM chosen by the 2026-07 modeling council.
# It found (via leave-one-out cross-validation, not in-sample R2) that:
#   * a SINGLE linear VIIRS-NDVI term is the best predictor of detrended yield;
#   * temperature and NDVI-squared curvature do NOT improve out-of-sample skill on
#     the short (n=14) series and are dropped;
#   * linear vs quadratic tech-detrend is picked PER STATE by CV;
#   * the honest headline is the CROSS-VALIDATED R2 (in-sample R2 overstates skill).
# Because it is NDVI-only it needs no weather archive.
# ---------------------------------------------------------------------------
def _poly_trend(years, vals, degree):
    """Fit a degree-`degree` yield trend; return {year: fitted} or None."""
    n = len(years)
    X = [[y ** p for p in range(degree + 1)] for y in years]
    XtX = [[sum(X[r][a] * X[r][b] for r in range(n)) for b in range(degree + 1)]
           for a in range(degree + 1)]
    Xty = [sum(X[r][a] * vals[r] for r in range(n)) for a in range(degree + 1)]
    beta = stats._mat_solve(XtX, Xty)
    if beta is None:
        return None
    return {years[i]: sum(beta[p] * (years[i] ** p) for p in range(degree + 1))
            for i in range(n)}


def _loo_cv_uni(Y, X):
    """Leave-one-out cross-validated R2 for a univariate OLS y ~ x (out-of-sample
    skill). Negative/near-zero => the in-sample fit does not generalize."""
    n = len(Y)
    ybar = sum(Y) / n
    sst = sum((v - ybar) ** 2 for v in Y)
    if sst <= 0:
        return None
    sse = 0.0
    for i in range(n):
        sx = sy = sxx = sxy = 0.0
        m = 0
        for j in range(n):
            if j == i:
                continue
            sx += X[j]; sy += Y[j]; sxx += X[j] * X[j]; sxy += X[j] * Y[j]; m += 1
        den = m * sxx - sx * sx
        if den == 0:
            return None
        b1 = (m * sxy - sx * sy) / den
        b0 = (sy - b1 * sx) / m
        sse += (Y[i] - (b0 + b1 * X[i])) ** 2
    return round(1 - sse / sst, 3)


def _ndvi_regression(ndvi_by_year, yield_data, cy):
    """detrended yield ~ single linear VIIRS-NDVI term. Auto-picks linear vs
    quadratic tech-detrend by leave-one-out CV, gated on the model F-test p<0.05
    and the NDVI coefficient p<0.10. Returns a reg dict (with loo_cv_r2) or None."""
    years_all = (yield_data or {}).get("years")
    vals_all = (yield_data or {}).get("values")
    if not years_all or not vals_all or not ndvi_by_year:
        return None
    ndvi_by_year = {int(k): v for k, v in ndvi_by_year.items() if v is not None}
    cand = None
    for degree, name in ((1, "linear"), (2, "quadratic")):
        trend = _poly_trend(years_all, vals_all, degree)
        if trend is None:
            continue
        resid = {y: vals_all[i] - trend[y] for i, y in enumerate(years_all)}
        yrs = sorted(y for y in ndvi_by_year if y in resid)
        if len(yrs) < 6:
            continue
        Y = [resid[y] for y in yrs]
        X = [ndvi_by_year[y] for y in yrs]
        fit = stats.ols(Y, [X])
        if not fit:
            continue
        f_p, p_ndvi = fit["p_model"], fit["p_coef"][1]
        loo = _loo_cv_uni(Y, X)
        passed = (f_p is not None and f_p < 0.05 and p_ndvi is not None and p_ndvi < 0.10)
        rec = {"degree": degree, "detrend": name, "trend": trend, "yrs": yrs, "Y": Y, "X": X,
               "b0": fit["beta"][0], "b1": fit["beta"][1], "r2": round(fit["r2"], 3),
               "adj_r2": round(fit["adj_r2"], 3) if fit["adj_r2"] is not None else None,
               "rmse": round(fit["rmse"], 2), "f_p": f_p, "p_ndvi": p_ndvi,
               "loo": loo, "n": len(yrs), "passed": passed}
        # prefer a PASSING model, tie-broken by higher LOO-CV; keep a best non-passing
        # one only so the panel can still show "no significant signal"
        take = False
        if cand is None:
            take = True
        elif rec["passed"] and not cand["passed"]:
            take = True
        elif rec["passed"] == cand["passed"]:
            rl, cl = rec["loo"], cand["loo"]
            take = rl is not None and (cl is None or rl > cl)
        if take:
            cand = rec
    if cand is None:
        return None
    trend, yrs = cand["trend"], cand["yrs"]
    value_by = {y: vals_all[i] for i, y in enumerate(years_all)}
    pyears, pactual, ppred = [], [], []
    for k, y in enumerate(yrs):
        pyears.append(y)
        pactual.append(round(value_by[y], 1))
        ppred.append(round(trend[y] + cand["b0"] + cand["b1"] * cand["X"][k], 1))
    reg = {
        "model": "detrended yield ~ VIIRS NDVI", "detrend": cand["detrend"],
        "b0": round(cand["b0"], 3), "b1": round(cand["b1"], 4),
        "r2": cand["r2"], "adj_r2": cand["adj_r2"], "loo_cv_r2": cand["loo"],
        "rmse": cand["rmse"], "f_p": cand["f_p"], "p_ndvi": cand["p_ndvi"],
        "r_ndvi": stats.pearson(cand["X"], cand["Y"]),
        "n": cand["n"], "years": [yrs[0], yrs[-1]],
        "significant": cand["passed"],
        "skillful": bool(cand["passed"] and cand["loo"] is not None and cand["loo"] > 0),
        "points": {"years": pyears, "actual": pactual, "predicted": ppred, "unit": "bu/ac"},
        "removed": 0, "removed_years": [],
    }
    _set_expected_yield(reg, yield_data, cy)
    return reg


# ---------------------------------------------------------------------------
# AUTO-SELECTING multi-variable yield model (council 2026-07-01, part 2).
# For each region it searches every combination (1-3) of dashboard predictors and
# both tech-detrends, and keeps the one with the HIGHEST leave-one-out CV R2 that
# passes the gate (F p<0.05 AND every coefficient p<0.10) — so each state/US gets
# the highest honest cross-validated skill. Archive-free (NASS + GLAM NDVI).
# ---------------------------------------------------------------------------
_PRED_LABELS = {"ndvi": "NDVI", "ge": "G+E", "cci": "CCI",
                "soil_short": "Soil short", "soil_surplus": "Soil surplus", "silk": "Silking"}
_PRED_ORDER = ["ndvi", "ge", "cci", "soil_short", "soil_surplus", "silk"]


def _loo_cv_multi(Y, Xcols):
    """Leave-one-out CV R2 for a multi-variable OLS (out-of-sample skill)."""
    n = len(Y)
    ybar = sum(Y) / n
    sst = sum((v - ybar) ** 2 for v in Y)
    if sst <= 0:
        return None
    p = len(Xcols) + 1
    sse = 0.0
    for i in range(n):
        idx = [j for j in range(n) if j != i]
        m = len(idx)
        X = [[1.0] + [Xcols[a][j] for a in range(len(Xcols))] for j in idx]
        Yt = [Y[j] for j in idx]
        XtX = [[sum(X[r][a] * X[r][b] for r in range(m)) for b in range(p)] for a in range(p)]
        Xty = [sum(X[r][a] * Yt[r] for r in range(m)) for a in range(p)]
        beta = stats._mat_solve(XtX, Xty)
        if beta is None:
            return None
        pred = beta[0] + sum(beta[k + 1] * Xcols[k][i] for k in range(len(Xcols)))
        sse += (Y[i] - pred) ** 2
    return round(1 - sse / sst, 3)


def _prefer_model(cand, best):
    """Higher LOO-CV wins; ties within 0.005 break toward FEWER variables."""
    dl = cand["loo"] - best["loo"]
    if dl > 0.005:
        return True
    if dl < -0.005:
        return False
    return len(cand["combo"]) < len(best["combo"])


def select_best_model(pred_by_year, yield_data, cy, max_vars=3):
    """Pick the predictor combination + detrend with the highest GATED leave-one-out
    CV R2. pred_by_year = {varname: {year: value}}. Returns a reg dict or None."""
    years_all = (yield_data or {}).get("years")
    vals_all = (yield_data or {}).get("values")
    if not years_all or not vals_all:
        return None
    avail = {k: {int(y): v for y, v in (d or {}).items() if v is not None}
             for k, d in pred_by_year.items()}
    varnames = [v for v in _PRED_ORDER if avail.get(v)]
    if not varnames:
        return None
    best = None
    for degree, dname in ((1, "linear"), (2, "quadratic")):
        trend = _poly_trend(years_all, vals_all, degree)
        if not trend:
            continue
        resid = {y: vals_all[i] - trend[y] for i, y in enumerate(years_all)}
        for k in range(1, max_vars + 1):
            for combo in itertools.combinations(varnames, k):
                yrs = sorted(y for y in resid if all(y in avail[v] for v in combo))
                # robustness floor: ~6 observations per predictor (and >=8 total) so a
                # short sample can't support too many variables (small-n overfit guard)
                if len(yrs) < max(8, 6 * k):
                    continue
                Y = [resid[y] for y in yrs]
                Xcols = [[avail[v][y] for y in yrs] for v in combo]
                res = stats.ols(Y, Xcols)
                if not res:
                    continue
                fp = res["p_model"]
                coefp = res["p_coef"][1:]
                if fp is None or fp >= 0.05:                       # model not significant
                    continue
                if any(p is None or p >= 0.10 for p in coefp):     # a predictor not significant
                    continue
                loo = _loo_cv_multi(Y, Xcols)
                if loo is None:
                    continue
                cand = {"combo": list(combo), "detrend": dname, "trend": trend, "yrs": yrs,
                        "Xcols": Xcols, "beta": res["beta"], "r2": round(res["r2"], 3),
                        "adj_r2": round(res["adj_r2"], 3) if res["adj_r2"] is not None else None,
                        "rmse": round(res["rmse"], 2), "f_p": fp, "coef_p": res["p_coef"],
                        "loo": loo, "n": len(yrs)}
                if best is None or _prefer_model(cand, best):
                    best = cand
    if best is None:
        return None
    trend, yrs, combo, beta = best["trend"], best["yrs"], best["combo"], best["beta"]
    vals_by = {y: v for y, v in zip(years_all, vals_all)}
    pyears, pactual, ppred = [], [], []
    for idx, y in enumerate(yrs):
        pyears.append(y)
        pactual.append(round(vals_by[y], 1))
        pv = trend[y] + beta[0] + sum(beta[k + 1] * best["Xcols"][k][idx] for k in range(len(combo)))
        ppred.append(round(pv, 1))
    coefs = {combo[k]: round(beta[k + 1], 4) for k in range(len(combo))}
    coef_p = {combo[k]: best["coef_p"][k + 1] for k in range(len(combo))}
    reg = {
        "model": "detrended yield ~ " + " + ".join(_PRED_LABELS.get(v, v) for v in combo),
        "predictors": combo, "labels": [_PRED_LABELS.get(v, v) for v in combo],
        "detrend": best["detrend"], "b0": round(beta[0], 3), "coefs": coefs, "coef_p": coef_p,
        "r2": best["r2"], "adj_r2": best["adj_r2"], "loo_cv_r2": best["loo"],
        "rmse": best["rmse"], "f_p": best["f_p"], "n": best["n"], "years": [yrs[0], yrs[-1]],
        "significant": True, "skillful": bool(best["loo"] is not None and best["loo"] > 0),
        "points": {"years": pyears, "actual": pactual, "predicted": ppred, "unit": "bu/ac"},
        "removed": 0, "removed_years": [],
    }
    if "ndvi" in combo:                    # keep single-var keys for back-compat display
        reg["b1"] = coefs["ndvi"]
        reg["p_ndvi"] = coef_p["ndvi"]
    _set_expected_yield(reg, yield_data, cy)
    return reg


def _fetch_predictors(cfg, key, usps, fid, cy):
    """Assemble the per-year candidate predictor series for one region (archive-free:
    GLAM NDVI + NASS condition/soil/silking). usps=None or 'US' => national query."""
    y0 = max(int(cfg.get("regression_start_year", 2008)), 2005)
    st = None if (usps in (None, "US")) else usps
    pred = {}
    if fid is not None:
        try:
            nd = glam.late_ndvi_by_year(cfg, fid, max(y0, 2012), cy - 1)   # VIIRS 2012+
            if nd:
                pred["ndvi"] = nd
        except Exception:
            pass
    try:
        cond = nass.late_condition_by_year(key, st, y0)
        if cond:
            pred["ge"] = {y: c["ge"] for y, c in cond.items() if c.get("ge") is not None}
            pred["cci"] = {y: c["cci"] for y, c in cond.items() if c.get("cci") is not None}
    except Exception:
        pass
    try:
        soil = nass.topsoil_by_year(key, st, y0)
        if soil:
            pred["soil_short"] = {y: s["short"] for y, s in soil.items() if s.get("short") is not None}
            pred["soil_surplus"] = {y: s["surplus"] for y, s in soil.items() if s.get("surplus") is not None}
    except Exception:
        pass
    try:
        silk = nass.silking_by_year(key, st, y0)
        if silk:
            pred["silk"] = silk
    except Exception:
        pass
    return pred


def _build_regression(cfg, key, fid, usps, cy, yield_data):
    """Per-state model: auto-select the best cross-validated combination of the
    dashboard's predictors (NDVI, condition, soil moisture, silking)."""
    if not yield_data:
        return None
    pred = _fetch_predictors(cfg, key, usps, fid, cy)
    if not pred:
        return None
    return select_best_model(pred, yield_data, cy)


def _correlation_weeks(cond, dev, cy):
    """Build the selectable Current(latest week)/Final(week 39) correlations."""
    if not cond or not dev:
        return None
    gbwy = cond.get("ge_by_week_year") or {}
    resid_by_year = {yr: rv for yr, rv in zip(dev["years"], dev["residuals"])
                     if rv is not None}
    cur_weeks = [int(w) for w, yrs in gbwy.items()
                 if str(cy) in yrs and yrs[str(cy)] is not None]
    current_week = max(cur_weeks) if cur_weeks else 26
    cw = {}
    c1 = _week_corr(gbwy, resid_by_year, current_week)
    if c1:
        cw["current"] = c1
    c2 = _week_corr(gbwy, resid_by_year, 39)
    if c2:
        cw["final"] = c2
    if not cw:
        return None
    cw["current_week"] = current_week
    cw["final_week"] = 39
    return cw


def _gdd_evolution(cfg, lat, lon, today, gdd_series_result):
    """Year-round cumulative GDD: prior years (archive) + current year (forecast) +
    the climatological normal, aligned on a shared MM-DD grid — like the NDVI chart."""
    n = int(cfg.get("gdd_evolution_years", 3))
    sm = int(cfg["gdd_start_month"])
    try:
        prior = openmeteo.gdd_by_year(lat, lon, today.year - n, today.year - 1, sm)
    except Exception:
        prior = None
    if not prior or not prior.get("dates"):
        return None
    dates = prior["dates"]
    idx = {d: i for i, d in enumerate(dates)}
    years = {k: v for k, v in prior["years"].items()}
    # current year from the forecast-based cumulative (fresh, through today)
    cur = [None] * len(dates)
    if gdd_series_result and gdd_series_result.get("dates"):
        for d, v in zip(gdd_series_result["dates"], gdd_series_result["actual_cum"]):
            if d in idx:
                cur[idx[d]] = v
    years[str(today.year)] = cur
    # cumulative normal from the per-DOY GDD normal
    normal = None
    try:
        gnorm = openmeteo.gdd_normal(lat, lon)
    except Exception:
        gnorm = None
    if gnorm:
        sm_doy = datetime.date(2021, sm, 1).timetuple().tm_yday
        run, cum = 0.0, [0.0] * 367
        for doy in range(1, 367):
            if doy >= sm_doy and doy < len(gnorm) and gnorm[doy] is not None:
                run += gnorm[doy]
            cum[doy] = run
        normal = [round(cum[datetime.date(2021, int(d[:2]), int(d[3:])).timetuple().tm_yday]) for d in dates]
    ev = {"dates": dates, "years": years, "normal": normal, "current_year": today.year}
    if normal:  # a real climatological normal (2011-20) was computed from the archive
        ev["normal_label"] = "Normal (2011-20)"
        ev["normal_kind"] = "climatology"
    return ev


def build_state(cfg, key, st, fmap, today):
    cy = today.year
    res = {"name": st.name, "usps": st.usps, "has_data": False}

    # --- corn-production-weighted point (county data lags ~1-2 yrs) ---
    prod = []
    for y in (cy - 1, cy - 2, cy - 3):
        prod = nass.county_production(key, st.usps, y)
        if prod:
            break
    point = (corn_points.production_weighted_point(st.usps, prod, cfg["top_counties_for_centroid"])
             if prod else corn_points.state_fallback_point(st.usps))
    res["corn_point"] = point

    # --- phenology (CURRENT crop year only) ---
    # Never fall back to last year: a stale snapshot is carried by _merge_previous,
    # and showing last year's finished season as "current" (e.g. silking 96% in
    # June) is worse than showing no data.
    res["phenology"] = nass.phenology(key, st.usps, cy)

    # --- topsoil moisture: USDA ground-truth wet/dry survey (current year only) ---
    res["topsoil_moisture"] = nass.topsoil_moisture(key, st.usps, cy)

    # --- condition: donut + G+E line + season averages ---
    cond = nass.condition_history(key, st.usps, cy - int(cfg["condition_history_years"]), cy)
    if cond:
        res["condition_latest"] = cond["latest"]
        res["ge_line"] = cond["ge_line"]
        res["ge_evolution"] = cond["ge_evolution"]
        res["cci_evolution"] = cond["cci_evolution"]
        res["condition_table"] = cond["condition_table"]

    # --- yield + trend + detrended deviation ---
    ys = nass.yield_series(key, st.usps, cfg["yield_start_year"])
    if ys and len(ys["years"]) >= 2:
        fit = stats.linear_trend(ys["years"], ys["values"])
        if fit:
            slope, intercept = fit
            res["yield"] = {
                "years": ys["years"],
                "values": ys["values"],
                "trend": stats.trend_line(ys["years"], slope, intercept),
            }
            res["yield_deviation"] = {
                "years": ys["years"],
                "residuals": stats.detrend(ys["years"], ys["values"], slope, intercept),
            }

    # --- correlation: late-season G+E vs DETRENDED yield (by year) ---
    # Raw yield trends upward, which would swamp the signal, so we correlate
    # against the yield deviation (residual from trend) computed above.
    dev = res.get("yield_deviation")
    if cond and dev:
        resid_by_year = {yr: rv for yr, rv in zip(dev["years"], dev["residuals"])
                         if rv is not None}
        xs, yv = [], []
        for yr, ge in sorted(cond["ge_by_year"].items()):
            if yr in resid_by_year:
                xs.append(ge)
                yv.append(resid_by_year[yr])
        corr = stats.correlation_clean(xs, yv)
        if corr:
            res["correlation"] = corr
        cw = _correlation_weeks(cond, dev, cy)
        if cw:
            res["correlation_weeks"] = cw

    # --- weather + soil moisture at the corn point ---
    if point:
        try:
            fc = openmeteo.fetch_forecast(point["lat"], point["lon"])
            res["soil_moisture"] = openmeteo.soil_moisture(fc)
            norm = openmeteo.normals(point["lat"], point["lon"])
            res["weather_anomaly"] = openmeteo.weather_anomaly(fc, norm)
            # per-model comparison: GFS (American) vs ECMWF (European)
            wxm = {}
            for nm, ml in (("GFS", "gfs_seamless"), ("ECMWF", "ecmwf_ifs025")):
                try:
                    wa = openmeteo.weather_anomaly(
                        openmeteo.forecast_model(point["lat"], point["lon"], ml), norm)
                    if wa:
                        wxm[nm] = wa
                except Exception:
                    pass
            if wxm:
                res["weather_models"] = wxm
            # observed monthly climate table (Jun-Sep precip + temp vs normal)
            try:
                res["climate_table"] = openmeteo.monthly_climate(
                    point["lat"], point["lon"], cy, today, norm)
            except Exception:
                pass
        except Exception as exc:  # best-effort; needs the (rate-limited) archive
            _log(f"    ! weather failed for {st.usps}: {exc}")
        # GDD is independent (actual from the forecast endpoint), so it survives
        # a weather/normals failure on its own.
        try:
            gstart = datetime.date(today.year, int(cfg["gdd_start_month"]), 1)
            if today >= gstart:
                res["gdd"] = openmeteo.gdd_series(
                    point["lat"], point["lon"], gstart.isoformat(), today.isoformat())
                ev = _gdd_evolution(cfg, point["lat"], point["lon"], today, res["gdd"])
                if ev:
                    res["gdd_evolution"] = ev
        except Exception as exc:
            _log(f"    ! GDD failed for {st.usps}: {exc}")
        # soil moisture by model (ECMWF + GEM), volumetric % today + 10-day
        try:
            res["soil_models"] = openmeteo.soil_models(point["lat"], point["lon"])
        except Exception as exc:
            _log(f"    ! soil models failed for {st.usps}: {exc}")

    # --- NDVI (GLAM, corn-masked) ---
    fid = fmap.get(st.name)
    if fid is not None:
        try:
            res["ndvi"] = glam.ndvi_for_state(cfg, fid, today)
        except Exception as exc:
            _log(f"    ! NDVI failed for {st.usps}: {exc}")

    # --- auto-selected yield model: best cross-validated combo of dashboard vars ---
    if res.get("yield"):
        try:
            res["regression"] = _build_regression(cfg, key, fid, st.usps, cy, res.get("yield"))
        except Exception as exc:
            _log(f"    ! regression failed for {st.usps}: {exc}")

    res["has_data"] = any(
        res.get(k) for k in
        ("phenology", "condition_latest", "yield", "ndvi", "soil_moisture")
    )
    return res


def _weights(ranking):
    return {r["usps"]: r["bu"] for r in ranking if r.get("bu")}


def _wavg_series(out, weights, field, label_key, value_keys):
    """Production-weighted average of a per-state series, aligned by label."""
    agg = {}
    for usps, w in weights.items():
        st = out.get(usps)
        ser = st.get(field) if st else None
        if not ser:
            continue
        for i, lab in enumerate(ser.get(label_key) or []):
            slot = agg.setdefault(lab, {vk: [] for vk in value_keys})
            for vk in value_keys:
                arr = ser.get(vk) or []
                if i < len(arr) and arr[i] is not None:
                    slot[vk].append((w, arr[i]))
    if not agg:
        return None
    labels = sorted(agg.keys())
    res = {label_key: labels}
    for vk in value_keys:
        out_vals = []
        for lab in labels:
            pairs = agg[lab][vk]
            tw = sum(w for w, _ in pairs)
            out_vals.append(round(sum(w * v for w, v in pairs) / tw, 3) if tw > 0 else None)
        res[vk] = out_vals
    return res


def _wavg_weather(out, weights):
    keys = ["temp", "precip_mm", "precip_pct"]
    # window count follows whatever weather_anomaly currently emits (now 4: +1-15 d)
    nwin = 0
    labels = None
    for usps in weights:
        st = out.get(usps)
        wx = st.get("weather_anomaly") if st else None
        if wx and wx.get("windows"):
            nwin = len(wx["windows"])
            labels = wx["windows"]
            break
    if not nwin:
        return None
    acc = {k: [[] for _ in range(nwin)] for k in keys}
    for usps, w in weights.items():
        st = out.get(usps)
        wx = st.get("weather_anomaly") if st else None
        if not wx:
            continue
        for k in keys:
            arr = wx.get(k) or []
            for i in range(min(nwin, len(arr))):
                if arr[i] is not None:
                    acc[k][i].append((w, arr[i]))
    res, any_data = {"windows": labels}, False
    for k in keys:
        vals = []
        for i in range(nwin):
            pairs = acc[k][i]
            tw = sum(w for w, _ in pairs)
            if tw > 0:
                vals.append(round(sum(w * v for w, v in pairs) / tw, 1))
                any_data = True
            else:
                vals.append(None)
        res[k] = vals
    return res if any_data else None


def build_national_nass(cfg, key, today, natl, prod_year):
    """National NASS half of the 'United States' view — fetched EARLY (freshest)."""
    cy = today.year
    res = {"name": "United States", "usps": "US", "has_data": True,
           "is_national": True, "corn_point": None}

    res["phenology"] = nass.phenology(key, None, cy)  # current crop year only
    res["topsoil_moisture"] = nass.topsoil_moisture(key, None, cy)  # US-wide survey
    cond = nass.condition_history(key, None, cy - int(cfg["condition_history_years"]), cy)
    if cond:
        res["condition_latest"] = cond["latest"]
        res["ge_line"] = cond["ge_line"]
        res["ge_evolution"] = cond["ge_evolution"]
        res["cci_evolution"] = cond["cci_evolution"]
        res["condition_table"] = cond["condition_table"]

    ys = nass.yield_series(key, None, cfg["yield_start_year"])
    if ys and len(ys["years"]) >= 2:
        fit = stats.linear_trend(ys["years"], ys["values"])
        if fit:
            slope, intercept = fit
            res["yield"] = {"years": ys["years"], "values": ys["values"],
                            "trend": stats.trend_line(ys["years"], slope, intercept)}
            res["yield_deviation"] = {"years": ys["years"],
                                      "residuals": stats.detrend(ys["years"], ys["values"], slope, intercept)}

    dev = res.get("yield_deviation")
    if cond and dev:
        resid = {yr: rv for yr, rv in zip(dev["years"], dev["residuals"]) if rv is not None}
        xs, yv = [], []
        for yr, ge in sorted(cond["ge_by_year"].items()):
            if yr in resid:
                xs.append(ge)
                yv.append(resid[yr])
        corr = stats.correlation_clean(xs, yv)
        if corr:
            res["correlation"] = corr
        cw = _correlation_weeks(cond, dev, cy)
        if cw:
            res["correlation_weeks"] = cw

    res["production"] = None  # flagged national -> renderProd shows the leaderboard
    res["national_production_bu"] = natl
    res["production_year"] = prod_year
    return res


def _national_ndvi_evolution(out, weights):
    """Production-weighted national year-round NDVI evolution, built by aligning the
    per-state evolutions on their shared date grid (already in the payload)."""
    canon = None
    for u in weights:
        e = ((out.get(u) or {}).get("ndvi") or {}).get("evolution")
        if e and e.get("dates") and (canon is None or len(e["dates"]) > len(canon)):
            canon = e["dates"]
    if not canon:
        return None
    idx = {d: i for i, d in enumerate(canon)}
    cy, yearkeys = None, set()
    for u in weights:
        e = ((out.get(u) or {}).get("ndvi") or {}).get("evolution")
        if e:
            cy = e.get("current_year")
            yearkeys |= set((e.get("years") or {}).keys())

    def wavg(getter):
        num = [0.0] * len(canon)
        den = [0.0] * len(canon)
        for u, w in weights.items():
            e = ((out.get(u) or {}).get("ndvi") or {}).get("evolution")
            if not e:
                continue
            arr = getter(e)
            if not arr:
                continue
            for i, d in enumerate(e.get("dates") or []):
                j = idx.get(d)
                v = arr[i] if i < len(arr) else None
                if j is not None and v is not None:
                    num[j] += w * v
                    den[j] += w
        return [round(num[j] / den[j], 3) if den[j] > 0 else None for j in range(len(canon))]

    years_out = {y: wavg(lambda e, y=y: (e.get("years") or {}).get(y)) for y in sorted(yearkeys)}
    current = wavg(lambda e: e.get("current"))
    prior = [y for y in years_out if str(y) != str(cy)]
    band_min, band_max = [], []
    for j in range(len(canon)):
        col = [years_out[y][j] for y in prior if years_out[y][j] is not None]
        band_min.append(round(min(col), 3) if col else None)
        band_max.append(round(max(col), 3) if col else None)
    return {"dates": canon, "current": current, "current_year": cy,
            "years": years_out, "band_min": band_min, "band_max": band_max}


def _national_regression(res, weights, cfg, key, fmap, cy):
    """National auto-selected model. National predictors come from the NATIONAL NASS
    query (condition/soil/silking) plus a production-weighted national NDVI; the
    selector picks the best cross-validated combo (the council found condition wins
    nationally, since a single US-wide NDVI mean overfits)."""
    yd = res.get("yield")
    if not yd:
        return None
    y0 = max(int(cfg.get("regression_start_year", 2008)), 2005)
    pred = _fetch_predictors(cfg, key, "US", None, cy)      # national NASS predictors
    # national NDVI = production-weighted top-25 states (2012+)
    top = sorted(weights.items(), key=lambda kv: kv[1], reverse=True)[:25]
    num, den = {}, {}
    for u, w in top:
        st = BY_USPS.get(u)
        fid = fmap.get(st.name) if st else None
        if fid is None:
            continue
        try:
            ly = glam.late_ndvi_by_year(cfg, fid, max(y0, 2012), cy - 1)
        except Exception:
            continue
        for yr, v in ly.items():
            num[yr] = num.get(yr, 0.0) + w * v
            den[yr] = den.get(yr, 0.0) + w
    ndviy = {yr: num[yr] / den[yr] for yr in num if den[yr] > 0}
    if ndviy:
        pred["ndvi"] = ndviy
    return select_best_model(pred, yd, cy)


def national_aggregates(res, out, ranking, today, cfg, fmap, key):
    """Add production-weighted geo aggregates (soil/weather/NDVI/GDD/regression) to the national view."""
    weights = _weights(ranking)

    # national soil moisture (by model) at the production-weighted corn centroid
    pts = [(out[u]["corn_point"], weights[u]) for u in weights
           if out.get(u) and out[u].get("corn_point")]
    if pts:
        tw = sum(w for _p, w in pts)
        lat = sum(p["lat"] * w for p, w in pts) / tw
        lon = sum(p["lon"] * w for p, w in pts) / tw
        try:
            res["soil_models"] = openmeteo.soil_models(lat, lon)
        except Exception:
            res["soil_models"] = None
        try:
            cnorm = openmeteo.normals(lat, lon)
            # Compute the national "Blend" anomaly at the SAME centroid point as the
            # GFS/ECMWF table below, so the bars and the model table are directly
            # comparable (a production-weighted state average would not line up).
            try:
                res["weather_anomaly"] = openmeteo.weather_anomaly(
                    openmeteo.fetch_forecast(lat, lon), cnorm)
            except Exception:
                pass
            wxm = {}
            for nm, ml in (("GFS", "gfs_seamless"), ("ECMWF", "ecmwf_ifs025")):
                try:
                    wa = openmeteo.weather_anomaly(openmeteo.forecast_model(lat, lon, ml), cnorm)
                    if wa:
                        wxm[nm] = wa
                except Exception:
                    pass
            if wxm:
                res["weather_models"] = wxm
            try:
                res["climate_table"] = openmeteo.monthly_climate(lat, lon, today.year, today, cnorm)
            except Exception:
                pass
        except Exception:
            pass
        # national multiple regression (uses the same centroid + cached per-state data)
        try:
            reg = _national_regression(res, weights, cfg, key, fmap, today.year)
            if reg:
                res["regression"] = reg
        except Exception:
            pass
        # national year-round GDD evolution at the centroid
        try:
            gstart = datetime.date(today.year, int(cfg["gdd_start_month"]), 1)
            cgdd = (openmeteo.gdd_series(lat, lon, gstart.isoformat(), today.isoformat())
                    if today >= gstart else None)
            ev = _gdd_evolution(cfg, lat, lon, today, cgdd)
            if ev:
                res["gdd_evolution"] = ev
        except Exception:
            pass

    soil = _wavg_series(out, weights, "soil_moisture", "dates", ["values"])
    if soil:
        cur = [(weights[u], out[u]["soil_moisture"]["current"]) for u in weights
               if out.get(u) and out[u].get("soil_moisture")
               and out[u]["soil_moisture"].get("current") is not None]
        if cur:
            tw = sum(w for w, _ in cur)
            soil["current"] = round(sum(w * v for w, v in cur) / tw, 3)
        soil["unit"] = "m³/m³"
    res["soil_moisture"] = soil

    # fall back to the production-weighted state average only if the centroid blend failed
    if not res.get("weather_anomaly"):
        res["weather_anomaly"] = _wavg_weather(out, weights)

    ndvi = _wavg_series(out, weights, "ndvi", "dates", ["values", "baseline", "anomaly"])
    if ndvi:
        ndvi["source"] = "GLAM VIIRS NDVI (corn-masked) · national, production-weighted"
        for u in weights:
            st = out.get(u)
            if st and st.get("ndvi") and st["ndvi"].get("baseline_years"):
                ndvi["baseline_years"] = st["ndvi"]["baseline_years"]
                break
        nat_evo = _national_ndvi_evolution(out, weights)
        if nat_evo:
            ndvi["evolution"] = nat_evo  # year-round, so the US view matches the states
    res["ndvi"] = ndvi

    gdd = _wavg_series(out, weights, "gdd", "dates", ["actual_cum", "normal_cum"])
    if gdd and gdd["dates"]:
        gdd["to_date"] = gdd["actual_cum"][-1]
        gdd["normal_to_date"] = gdd["normal_cum"][-1]
        gdd["pct_of_normal"] = (round(gdd["to_date"] / gdd["normal_to_date"] * 100)
                                if gdd["normal_to_date"] else None)
        gdd["through"] = gdd["dates"][-1]  # MM-DD label, matches per-state
    res["gdd"] = gdd
    return res


# Condition-derived fields are deliberately NOT carried over: they come from NASS
# (the always-allowlisted primary source), so if a state has no CURRENT-year condition
# the correct result is "no data", not last season's stale record resurrected forever.
# yield is also NASS but is annual+stable, so it's fine to carry. The rest come from
# the rate-limited Open-Meteo/GLAM sources and genuinely benefit from same-day carry.
CARRYABLE = ("soil_moisture", "soil_models", "weather_anomaly", "weather_models",
             "climate_table", "ndvi", "gdd", "gdd_evolution", "phenology",
             "yield", "yield_deviation", "regression")


def _merge_previous(cfg, out):
    """Carry over last-good panel data for anything this run couldn't refresh.

    Lets a restricted machine (firewall allowing only some sources) update what
    it can while preserving the rest from the previous snapshot, instead of
    overwriting good data with blanks. Carried panels are flagged so the UI can
    note they're from an earlier refresh.
    """
    path = os.path.join(cfg["data_dir"], "dashboard_data.json")
    if not os.path.exists(path):
        return
    try:
        with open(path, "r", encoding="utf-8") as fh:
            prev = json.load(fh)
    except (OSError, json.JSONDecodeError):
        return
    prev_states = prev.get("states", {})
    prev_ts = prev.get("generated_at")
    # Only warn the UI when carried data is from a PRIOR day (genuinely stale).
    # Same-day carry-over (e.g. a source throttled mid-run) is still current, so
    # we keep the data but don't flag it.
    today_day = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d")
    stale = bool(prev_ts) and prev_ts[:10] != today_day
    n = 0
    for usps, st in out.items():
        ps = prev_states.get(usps)
        if not ps:
            continue
        carried = [f for f in CARRYABLE if not st.get(f) and ps.get(f)]
        for f in carried:
            st[f] = ps[f]
        if carried:
            st["has_data"] = True
            n += 1
            if stale:
                st["carried_over"] = carried
                st["carried_from"] = prev_ts
    if n:
        note = "from a previous day — flagged" if stale else "same-day, still current"
        _log(f"  carried over last-good data for {n} states ({note})")


def _rebuild_only(cfg):
    """Regenerate index.html from the last data snapshot — no network calls.
    Use after editing the template/styling:  python src/update.py --rebuild
    """
    snap = os.path.join(cfg["data_dir"], "dashboard_data.json")
    if not os.path.exists(snap):
        _log("No data/dashboard_data.json yet — run a normal update first.")
        return 1
    with open(snap, "r", encoding="utf-8") as fh:
        payload = json.load(fh)
    out_path = build.render(cfg, payload)
    _log(f"Rebuilt dashboard from cached data: {out_path}")
    return 0


def main():
    cfg = config.load()

    if "--rebuild" in sys.argv:
        return _rebuild_only(cfg)

    try:
        key = config.require_nass_key(cfg)
    except config.ConfigError as exc:
        _log("ERROR: " + str(exc))
        return 2

    http_util.configure(
        ca_bundle=cfg["ca_bundle"],
        delay=cfg["request_delay_seconds"],
        timeout=cfg["request_timeout_seconds"],
        retries=cfg["request_retries"],
    )
    cache.init(cfg["data_dir"])

    today = datetime.date.today()
    sts = resolve(cfg["states"])
    _log(f"Gathering corn data for {len(sts)} states (first run is slower; "
         f"later runs reuse the cache)...")

    try:
        fmap = glam.feature_map()
    except Exception as exc:
        _log(f"  ! GLAM feature map unavailable ({exc}); NDVI will be skipped.")
        fmap = {}

    # --- US production share + ranking (1-2 calls total) ---
    prod_lookup, ranking, prod_year, natl = {}, [], None, None
    prod_by_state = {}
    for y in (today.year - 1, today.year - 2, today.year - 3):
        try:
            prod_by_state = nass.all_state_production(key, y)
        except nass.NassAuthError as exc:
            _log("ERROR: " + str(exc))
            return 2
        if prod_by_state:
            prod_year = y
            break
    if prod_year:
        try:
            natl = nass.national_production(key, prod_year)
        except Exception:
            natl = None
        if not natl:
            natl = sum(prod_by_state.values())
        if natl:  # guard divide-by-zero if no production reported
            ordered = sorted(((us, bu) for us, bu in prod_by_state.items() if us in BY_USPS),
                             key=lambda kv: kv[1], reverse=True)
            for rnk, (us, bu) in enumerate(ordered, 1):
                ranking.append({"usps": us, "name": BY_USPS[us].name, "bu": bu,
                                "share": round(bu / natl * 100, 2), "rank": rnk})
            prod_lookup = {r["usps"]: {"bu": r["bu"], "share": r["share"], "rank": r["rank"],
                                       "of": len(ranking), "year": prod_year} for r in ranking}
            _log(f"  production: ranked {len(ranking)} states for {prod_year} "
                 f"(US total {natl:,.0f} bu)")

    # national NASS first, while the API is freshest (geo aggregates added later)
    us_national = None
    try:
        us_national = build_national_nass(cfg, key, today, natl, prod_year)
        _log("  fetched national 'United States' NASS data")
    except nass.NassAuthError as exc:
        _log("ERROR: " + str(exc))
        return 2
    except Exception as exc:
        _log(f"  ! national NASS failed: {exc}")

    out = {}
    resumed = _load_checkpoint(cfg, today)
    if resumed:
        out.update(resumed)
        _log(f"  resuming from checkpoint: {len(out)} states already built today")
    t0 = time.time()
    for i, st in enumerate(sts, 1):
        if st.usps in out:
            _log(f"[{i:>2}/{len(sts)}] {st.name} ... (checkpoint)")
            continue
        _log(f"[{i:>2}/{len(sts)}] {st.name} ...")
        try:
            out[st.usps] = build_state(cfg, key, st, fmap, today)
        except nass.NassAuthError as exc:
            _log("ERROR: " + str(exc))
            return 2
        except Exception as exc:
            _log(f"    ! {st.usps} failed: {exc}")
            out[st.usps] = {"name": st.name, "usps": st.usps, "has_data": False}
        _save_checkpoint(cfg, today, out)  # flush after each state so a kill loses at most one

    # previous snapshot — used to carry production/national forward if THIS run's
    # NASS production fetch failed (429/5xx is swallowed to empty), so a transient
    # outage never blanks the whole leaderboard + every state's rank/share badge.
    prev = _load_prev(cfg)
    prev_states = prev.get("states", {}) if isinstance(prev, dict) else {}

    # attach production share/rank to each state (carry from prev when this run got none)
    for us in out:
        pd = prod_lookup.get(us)
        if pd:
            out[us]["production"] = pd
            out[us]["has_data"] = True
        elif not out[us].get("production"):
            pp = (prev_states.get(us) or {}).get("production")
            if pp:
                out[us]["production"] = pp

    # finalize the national view with production-weighted geo aggregates
    if us_national is not None:
        try:
            national_aggregates(us_national, out, ranking, today, cfg, fmap, key)
        except Exception as exc:
            _log(f"  ! national aggregates failed: {exc}")
        # carry the national total/year if this run's production fetch failed
        if prod_year is None:
            prev_us = prev_states.get("US") or {}
            if prev_us.get("national_production_bu"):
                us_national["national_production_bu"] = prev_us["national_production_bu"]
                us_national["production_year"] = prev_us.get("production_year")
        out["US"] = us_national
        _log("  built national 'United States' view")

    # non-destructive: keep last-good values for any panel a source couldn't
    # reach this run (e.g. a firewall that only allows the USDA domain), so a
    # restricted machine refreshes what it can and never blanks the rest.
    _merge_previous(cfg, out)

    # guarantee a fresh, correct trend-based expected_yield on every state that has a
    # yield trend — immune to a throttled archive or an older carried regression format
    _ensure_expected_yield(out, today.year)

    # top-level leaderboard block: carry the previous one if this run got no ranking
    prod_block = {"year": prod_year, "national_bu": natl, "ranking": ranking}
    if not ranking and (prev.get("production") or {}).get("ranking"):
        prod_block = prev["production"]

    payload = {
        "generated_at": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "states": out,
        "production": prod_block,
        "attribution": {
            "usda": "USDA NASS Quick Stats",
            "weather": "Open-Meteo (CC-BY 4.0, ERA5)",
            "ndvi": "NASA Harvest GLAM",
        },
    }

    os.makedirs(cfg["data_dir"], exist_ok=True)
    with open(os.path.join(cfg["data_dir"], "dashboard_data.json"), "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False)
    _clear_checkpoint(cfg)  # full run finished; next run starts fresh
    # ship a warm cache copy so the firewalled work machine can regenerate offline
    cache.export(os.path.join(cfg["data_dir"], "cache.sqlite"))

    out_path = build.render(cfg, payload)
    n_data = sum(1 for s in out.values() if s.get("has_data"))
    _log(f"\nDone in {time.time()-t0:.0f}s. {n_data}/{len(sts)} states have data.")
    _log(f"Dashboard written to: {out_path}")
    _log("Open index.html in your browser.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
