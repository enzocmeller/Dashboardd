"""Minimal, firewall-aware HTTP GET helpers built on the standard library only.

- Honors HTTP(S)_PROXY environment variables automatically (urllib default).
- Supports a corporate root-CA bundle (for TLS-intercepting proxies) so the
  dashboard does not die with CERTIFICATE_VERIFY_FAILED.
- Retries with backoff on transient (5xx / network) errors.
- Enforces a polite delay between requests.
"""
import gzip
import http.client
import json
import ssl
import time
import urllib.error
import urllib.request

_CTX = None          # ssl.SSLContext (or None for default)
_DELAY = 0.3         # seconds between requests to the SAME host
_TIMEOUT = 60
_RETRIES = 3
_last_request_ts = {}   # host -> ts of its last request (politeness is per-host:
                        # interleaved calls to different APIs shouldn't wait on each other)

USER_AGENT = "CornDashboard/1.0 (stdlib urllib; internal analytics)"


def configure(ca_bundle="", delay=0.3, timeout=60, retries=3):
    """Set up the shared SSL context and request policy. Call once at startup."""
    global _CTX, _DELAY, _TIMEOUT, _RETRIES
    _DELAY = float(delay)
    _TIMEOUT = int(timeout)
    _RETRIES = int(retries)
    if ca_bundle:
        # A bad/stale ca_bundle (often auto-adopted from SSL_CERT_FILE) must not crash
        # the whole run at startup — fall back to the system trust store.
        try:
            _CTX = ssl.create_default_context(cafile=ca_bundle)
        except (OSError, ssl.SSLError) as exc:
            print(f"  ! ca_bundle unusable ({ca_bundle}): {exc}; using system trust store", flush=True)
            _CTX = ssl.create_default_context()
    else:
        _CTX = ssl.create_default_context()


def _ctx():
    global _CTX
    if _CTX is None:
        _CTX = ssl.create_default_context()
    return _CTX


# Per-host MINIMUM spacing overrides: the per-host throttle removed the accidental
# extra spacing NASS used to get from interleaved slow calls to other hosts, and its
# WAF started dropping bursty runs — give it back a gentler floor.
_HOST_MIN_DELAY = {"quickstats.nass.usda.gov": 0.7}


def _throttle(host):
    d = max(_DELAY, _HOST_MIN_DELAY.get(host, 0.0))
    if d > 0:
        wait = d - (time.time() - _last_request_ts.get(host, 0.0))
        if wait > 0:
            time.sleep(wait)
    _last_request_ts[host] = time.time()


class HttpError(Exception):
    def __init__(self, status, url, message=""):
        self.status = status
        self.url = url
        super().__init__(f"HTTP {status} for {url} {message}".strip())


# Circuit breaker: once a host exhausts retries on 429s, fail fast for a short
# cooldown (host -> unix time it may be retried) instead of blocking it forever.
_blocked_hosts = {}
_consecutive_429 = {}       # host -> consecutive get_bytes() calls that exhausted on 429
_BLOCK_COOLDOWN = 120.0
_BREAKER_THRESHOLD = 3      # only open the breaker after this many in a row (one-off 429s recover)
_BREAKER_MAX = 300.0        # cap how long a host stays blocked (ignore a hostile Retry-After)


def _host(url):
    try:
        return url.split("/", 3)[2]
    except IndexError:
        return url


def get_bytes(url, headers=None, timeout=None):
    """GET a URL, returning raw bytes. Retries transient failures with backoff."""
    timeout = timeout or _TIMEOUT
    req_headers = {"User-Agent": USER_AGENT, "Accept": "*/*",
                   "Accept-Encoding": "gzip"}   # 5-10x smaller Open-Meteo payloads
    if headers:
        req_headers.update(headers)

    host = _host(url)
    blocked_until = _blocked_hosts.get(host)
    if blocked_until and time.time() < blocked_until:
        raise HttpError(429, url, "host rate-limited; in cooldown")

    last_exc = None
    retry_after_max = 0.0
    for attempt in range(_RETRIES + 1):
        _throttle(host)
        req = urllib.request.Request(url, headers=req_headers)
        backoff = min(8.0, 1.5 ** attempt)
        try:
            with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as resp:
                data = resp.read()
                if (resp.headers.get("Content-Encoding") or "").lower() == "gzip":
                    data = gzip.decompress(data)
                _consecutive_429.pop(host, None)   # success clears the 429 streak + any cooldown
                _blocked_hosts.pop(host, None)
                return data
        except urllib.error.HTTPError as exc:
            # 4xx are not worth retrying — EXCEPT 429 (rate limit) and 403 (WAF
            # burst-block: NASS intermittently 403s under load and clears in seconds)
            if exc.code not in (403, 429, 500, 502, 503, 504):
                body = ""
                try:
                    raw = exc.read()
                    if (exc.headers.get("Content-Encoding") or "").lower() == "gzip":
                        raw = gzip.decompress(raw)   # we request gzip; error bodies
                    body = raw.decode("utf-8", "replace")[:300]   # must decode too
                except Exception:
                    pass
                raise HttpError(exc.code, url, body)
            last_exc = HttpError(exc.code, url)
            if exc.code == 403:  # WAF burst-block: pause long enough for it to clear
                backoff = min(20.0, 4.0 * (attempt + 1))
            if exc.code == 429:  # rate limited: wait much longer (honor Retry-After, capped —
                ra = exc.headers.get("Retry-After") if exc.headers else None   # a hostile value
                try:                                                           # must not stall
                    ra_s = float(ra) if ra else 0.0                            # the run for hours)
                except (TypeError, ValueError):
                    ra_s = 0.0
                retry_after_max = max(retry_after_max, ra_s)
                backoff = min(ra_s, 120.0) if ra_s else min(60.0, 5.0 * (2 ** attempt))
        except (urllib.error.URLError, TimeoutError, ssl.SSLError, ConnectionError,
                http.client.HTTPException, gzip.BadGzipFile) as exc:
            # HTTPException covers IncompleteRead/BadStatusLine from truncating proxies;
            # these must RETRY here, not escape and abort a whole state upstream.
            last_exc = exc
        if attempt < _RETRIES:
            time.sleep(backoff)
    # exhausted retries on a 429: only open the breaker after several CONSECUTIVE
    # failed calls (a one-off 429 on one state must not blank every later state),
    # self-clearing on the next success. Honor Retry-After for the cooldown, capped.
    if isinstance(last_exc, HttpError) and last_exc.status == 429:
        n = _consecutive_429.get(host, 0) + 1
        _consecutive_429[host] = n
        if n >= _BREAKER_THRESHOLD:
            _blocked_hosts[host] = time.time() + min(_BREAKER_MAX, max(_BLOCK_COOLDOWN, retry_after_max))
    raise last_exc if last_exc else HttpError(0, url, "unknown error")


def get_text(url, headers=None, encoding="utf-8", timeout=None):
    return get_bytes(url, headers=headers, timeout=timeout).decode(encoding, "replace")


def get_json(url, headers=None, timeout=None):
    return json.loads(get_text(url, headers=headers, timeout=timeout))
