"""Open-Meteo client: 16-day forecast, soil moisture, ERA5 climate normals, and
forecast-vs-normal anomalies on the 1-5 / 6-10 / 11-15 / 1-15 day windows.

No API key (non-commercial/free). HTTPS/443 JSON. Standard library only.
ERA5 normals are immutable, so they are cached permanently per location.
"""
import datetime
import urllib.parse

import cache
import http_util

FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
ARCHIVE_URL = "https://archive-api.open-meteo.com/v1/archive"

# root-zone soil-moisture layers (cm) and their thickness weights
_SM_LAYERS = [
    ("soil_moisture_0_to_1cm", 1),
    ("soil_moisture_1_to_3cm", 2),
    ("soil_moisture_3_to_9cm", 6),
    ("soil_moisture_9_to_27cm", 18),
]


def _url(base, params):
    return base + "?" + urllib.parse.urlencode(params, quote_via=urllib.parse.quote)


def _today():
    return datetime.date.today().isoformat()


def fetch_forecast(lat, lon):
    """One call returns the daily temp/precip forecast + hourly soil moisture.
    Cached PER DAY so a re-run after a rate-limit cut-off reuses the states already
    fetched and spends the API budget on the ones that got skipped (converges)."""
    ckey = f"fc:{round(lat, 2)}:{round(lon, 2)}:{_today()}"
    hit = cache.get_json(ckey)
    if hit is not None:
        return hit
    params = {
        "latitude": f"{lat:.4f}",
        "longitude": f"{lon:.4f}",
        "daily": "temperature_2m_mean,precipitation_sum",
        "hourly": ",".join(name for name, _w in _SM_LAYERS),
        "forecast_days": "16",
        "timezone": "auto",
    }
    data = http_util.get_json(_url(FORECAST_URL, params))
    if data and data.get("daily"):
        cache.set_json(ckey, data)
    return data


# --- soil moisture by model (European ECMWF + Canadian GEM); GFS has none ---
# Root-zone layers, thickness-weighted: the 0-7 cm SURFACE is volatile and dries out
# between rains (it read ~20% "Poor" for wet-profile Illinois), so we use the crop's
# actual water-supply zone (~0-28/0-35 cm) instead. (layer_var, thickness_cm)
SOIL_MODELS = [
    # ECMWF exposes a real root zone (0-28 cm) -> the representative headline + grade.
    # (GEM's 0-10 cm surface row was REMOVED: a shallow read from a second model adds
    # noise, not signal — it invited misreading a dry surface as a dry profile, and
    # its open-water pixel bug (MD reading 100 %vol) forced the >60% mask. The
    # decision stack is USDA survey (ground truth) + ONE root-zone trajectory.)
    ("ECMWF", "ecmwf_ifs025",
     [("soil_moisture_0_to_7cm", 7), ("soil_moisture_7_to_28cm", 21)], "0–28 cm"),
]
# volumetric-% V/P/F/G/E thresholds (soil-agnostic; configurable)
_SOIL_GRADE = [(15, "V"), (22, "P"), (30, "F"), (38, "G")]


def soil_grade(pct):
    if pct is None:
        return None
    for thr, g in _SOIL_GRADE:
        if pct < thr:
            return g
    return "E"


def soil_models(lat, lon):
    """Root-zone volumetric soil-moisture % (today and +10 day) from ECMWF + GEM,
    thickness-weighted over the crop's water-supply zone, with a V/P/F/G/E grade.
    Cached per day (makes 2 forecast calls) so re-runs converge under rate limits."""
    ckey = f"soilfc:{round(lat, 2)}:{round(lon, 2)}:{_today()}"
    hit = cache.get_json(ckey)
    if hit is not None:
        return hit
    out = []
    for name, model, layers, label in SOIL_MODELS:
        variables = ",".join(v for v, _t in layers)
        params = {"latitude": f"{lat:.4f}", "longitude": f"{lon:.4f}", "hourly": variables,
                  "models": model, "forecast_days": "11", "timezone": "auto"}
        try:
            data = http_util.get_json(_url(FORECAST_URL, params))
        except Exception:
            continue
        hourly = data.get("hourly") or {}
        times = hourly.get("time") or []
        totth = sum(t for _v, t in layers)
        by_day = {}
        for i, t in enumerate(times):
            num, ok = 0.0, True
            for var, th in layers:
                arr = hourly.get(var) or []
                v = arr[i] if i < len(arr) else None
                if v is None:
                    ok = False
                    break
                num += v * th
            if ok:
                by_day.setdefault(t[:10], []).append(num / totth)  # thickness-weighted volumetric
        days = sorted(by_day)
        if not days:
            continue

        def dpct(d):
            a = by_day.get(d) or []
            return round(sum(a) / len(a) * 100, 1) if a else None

        today_pct = dpct(days[0])
        # Physically implausible volumetric moisture -> masked/invalid pixel: ~0 is
        # a mask value, and >60 %vol is open water (real soil saturates ~45-55; MD's
        # GEM pixel over Chesapeake Bay reads 100). Drop that model entirely.
        if today_pct is None or today_pct < 1.0 or today_pct > 60.0:
            continue
        out.append({"model": name, "layer": label,
                    "today": today_pct, "day10": dpct(days[min(10, len(days) - 1)])})
    if not out:
        return None
    primary = out[0]["today"]
    result = {"models": out, "current_pct": primary, "grade": soil_grade(primary), "unit": "% vol"}
    cache.set_json(ckey, result)
    return result


def forecast_model(lat, lon, model):
    """Daily temp/precip 15-day forecast for one model (gfs_seamless / ecmwf_ifs025).
    Cached per day (see fetch_forecast) so re-runs converge under rate limits."""
    ckey = f"fcm:{model}:{round(lat, 2)}:{round(lon, 2)}:{_today()}"
    hit = cache.get_json(ckey)
    if hit is not None:
        return hit
    params = {"latitude": f"{lat:.4f}", "longitude": f"{lon:.4f}",
              "daily": "temperature_2m_mean,precipitation_sum", "models": model,
              "forecast_days": "15", "timezone": "auto"}
    data = http_util.get_json(_url(FORECAST_URL, params))
    if data and data.get("daily"):
        cache.set_json(ckey, data)
    return data


def soil_moisture(forecast):
    """Daily root-zone (0-27 cm) volumetric soil moisture from the forecast."""
    hourly = forecast.get("hourly") or {}
    times = hourly.get("time") or []
    if not times:
        return None
    # accumulate per-day weighted sums
    day_acc = {}   # date -> [weighted_sum, weight_count]
    weights_total = sum(w for _n, w in _SM_LAYERS)
    per_hour = []
    for i, t in enumerate(times):
        num = 0.0
        wsum = 0
        for name, w in _SM_LAYERS:
            arr = hourly.get(name)
            if not arr or i >= len(arr) or arr[i] is None:
                continue
            num += arr[i] * w
            wsum += w
        if wsum == 0:
            continue
        val = num / wsum
        per_hour.append((t, val))
    for t, val in per_hour:
        d = t[:10]
        acc = day_acc.setdefault(d, [0.0, 0])
        acc[0] += val
        acc[1] += 1
    dates = sorted(day_acc)
    values = [round(day_acc[d][0] / day_acc[d][1], 3) for d in dates]
    if not values:
        return None
    # an all-~0 series means no soil grid over this point (e.g. a small island corn
    # point like Hawaii) -> report no data rather than a flat 0.0 line.
    if max(values) < 0.001:
        return None
    return {
        "current": values[0],
        "dates": [d[5:] for d in dates],
        "values": values,
        "unit": "m³/m³",
    }


def heat_stress(lat, lon, today, threshold_f=93.0, since_month=6):
    """Pollination heat-stress days: count of Tmax >= threshold since Jun 1 (observed)
    plus the 16-day forecast outlook. July heat during silking is the single biggest
    weather market-mover for corn, and cumulative GDD hides extremes — 10 mild days
    and 5 brutal ones can score the same. One forecast-endpoint call, day-cached."""
    tday = today if hasattr(today, "isoformat") else datetime.date.fromisoformat(str(today))
    start = datetime.date(tday.year, since_month, 1)
    if tday < start:
        return None
    past = min((tday - start).days, 92)   # Jun 1 -> Sep 1 fits the 92-day window
    ckey = f"heat:{round(lat, 2)}:{round(lon, 2)}:{tday.isoformat()}"
    hit = cache.get_json(ckey)
    if hit is not None:
        return hit
    params = {"latitude": f"{lat:.4f}", "longitude": f"{lon:.4f}",
              "daily": "temperature_2m_max", "past_days": str(past),
              "forecast_days": "16", "timezone": "auto"}
    data = http_util.get_json(_url(FORECAST_URL, params))
    daily = data.get("daily") or {}
    times = daily.get("time") or []
    tmax = daily.get("temperature_2m_max") or []
    thr_c = (threshold_f - 32.0) * 5.0 / 9.0
    past_n = fut_n = 0
    today_s = tday.isoformat()
    for i, t in enumerate(times):
        v = tmax[i] if i < len(tmax) else None
        if v is None or v < thr_c:
            continue
        if t <= today_s:
            past_n += 1
        else:
            fut_n += 1
    result = {"past_days": past_n, "next16": fut_n,
              "since": start.isoformat()[5:], "threshold_f": int(threshold_f)}
    if times:
        cache.set_json(ckey, result)
    return result


def precip_windows(lat, lon, today, norm, windows=(30, 60, 90)):
    """Rolling 30/60/90-day precipitation as % of the 1991-2020 normal — the closest
    in-firewall substitute for the Drought Monitor (unreachable domain). One small
    archive call per point per day; windows end at the last day the archive has."""
    if not norm or not norm.get("precip"):
        return None
    tday = today if hasattr(today, "isoformat") else datetime.date.fromisoformat(str(today))
    ckey = f"pwin:{round(lat, 2)}:{round(lon, 2)}:{tday.isoformat()}"
    hit = cache.get_json(ckey)
    if hit is not None:
        return hit
    start = tday - datetime.timedelta(days=max(windows) + 12)   # archive lags ~5 d
    params = {"latitude": f"{lat:.4f}", "longitude": f"{lon:.4f}",
              "start_date": start.isoformat(), "end_date": tday.isoformat(),
              "daily": "precipitation_sum", "timezone": "auto"}
    data = http_util.get_json(_url(ARCHIVE_URL, params))
    daily = data.get("daily") or {}
    times = daily.get("time") or []
    pp = daily.get("precipitation_sum") or []
    obs = [(t, pp[i]) for i, t in enumerate(times) if i < len(pp) and pp[i] is not None]
    if len(obs) < max(windows):
        return None
    result = {"as_of": obs[-1][0]}
    nprec = norm["precip"]
    for w in windows:
        chunk = obs[-w:]
        actual = sum(v for _t, v in chunk)
        normal = 0.0
        for t, _v in chunk:
            try:
                normal += nprec[_doy(t)] or 0.0
            except (IndexError, TypeError, ValueError):
                pass
        # a % of a near-zero normal is noise, not signal (Hawaii's ocean-adjacent
        # centroid has a ~0.3 mm/day ERA5 normal -> "460% of normal" from a drizzle).
        # Require >= ~0.5 mm/day of climatological normal before publishing a %.
        result[f"w{w}"] = round(actual / normal * 100) if normal >= 0.5 * w else None
        result[f"w{w}_mm"] = round(actual, 1)
    cache.set_json(ckey, result)
    return result


def _doy(date_str):
    return datetime.date.fromisoformat(date_str).timetuple().tm_yday


def _doy_climatology(daily, fields):
    """Build smoothed (±7 day) per-DOY normals for the requested daily fields."""
    times = daily.get("time") or []
    buckets = {f: [[] for _ in range(367)] for f in fields}
    for i, t in enumerate(times):
        try:
            d = _doy(t)
        except (ValueError, TypeError):
            continue
        for f in fields:
            arr = daily.get(f) or []
            if i < len(arr) and arr[i] is not None:
                buckets[f][d].append(arr[i])

    def base(lists):
        return [None if not lists[d] else sum(lists[d]) / len(lists[d]) for d in range(367)]

    def smooth(arr):
        out = [None] * 367
        for d in range(1, 367):
            win = [arr[((k - 1) % 366) + 1] for k in range(d - 7, d + 8)
                   if arr[((k - 1) % 366) + 1] is not None]
            out[d] = round(sum(win) / len(win), 3) if win else None
        return out

    return {f: smooth(base(buckets[f])) for f in fields}


def normals(lat, lon):
    """Smoothed day-of-year ERA5 1991-2020 normals (temp mean, precip). Cached forever.

    Fetched in DECADE chunks, each cached separately, so a 429 mid-way keeps the
    decades already fetched — the single 30-yr call was the heaviest, most
    429-prone request in the pipeline, and losing all progress on every rate limit
    is why some points stayed normal-less for days.
    """
    key = f"normals:{round(lat, 2)}:{round(lon, 2)}"
    cached = cache.get_json(key)
    if cached is not None:
        return cached
    merged = {"time": [], "temperature_2m_mean": [], "precipitation_sum": []}
    complete = True
    for y0, y1 in ((1991, 2000), (2001, 2010), (2011, 2020)):
        ckey = f"normchunk:{round(lat, 2)}:{round(lon, 2)}:{y0}"
        daily = cache.get_json(ckey)
        if daily is None:
            params = {"latitude": f"{lat:.4f}", "longitude": f"{lon:.4f}",
                      "start_date": f"{y0}-01-01", "end_date": f"{y1}-12-31",
                      "daily": "temperature_2m_mean,precipitation_sum", "timezone": "auto"}
            data = http_util.get_json(_url(ARCHIVE_URL, params))
            daily = data.get("daily") or {}
            if daily.get("time"):   # immutable decade: cache once fetched
                cache.set_json(ckey, daily)
            else:
                complete = False    # empty-but-200 response: decade missing
        for f in merged:
            merged[f].extend(daily.get(f) or [])
    clim = _doy_climatology(merged, ["temperature_2m_mean", "precipitation_sum"])
    result = {"temp": clim["temperature_2m_mean"], "precip": clim["precipitation_sum"]}
    # cache the merged normal ONLY when all three decades arrived — a 2-of-3 partial
    # frozen under this immutable key would bias every anomaly at this point forever
    if complete and merged["time"]:
        cache.set_json(key, result)
    return result


def gdd_f(tmax_c, tmin_c):
    """Daily corn growing-degree-days (base 50 °F, cap 86 °F) from °C max/min."""
    if tmax_c is None or tmin_c is None:
        return 0.0
    tmax = min(tmax_c * 9 / 5 + 32, 86.0)
    tmin = max(tmin_c * 9 / 5 + 32, 50.0)
    return max(0.0, (tmax + tmin) / 2.0 - 50.0)


def gdd_normal(lat, lon):
    """Per-DOY GDD normal from a 10-year ERA5 window (lighter archive call). Cached.

    CRUCIAL: the normal must be the mean of each day's GDD, NOT the GDD computed
    from day-of-year-mean temperatures. The 50 °F floor / 86 °F cap make
    gdd(mean_T) < mean(gdd(T)) in the shoulder seasons (Jensen's inequality), so
    the old temp-first approach biased the normal LOW and made every year read
    above-normal. We compute daily GDD first, then average per day-of-year.
    """
    key = f"gddnorm2:{round(lat, 2)}:{round(lon, 2)}"   # v2: daily-GDD-then-average
    cached = cache.get_json(key)
    if cached is not None:
        return cached
    params = {
        "latitude": f"{lat:.4f}",
        "longitude": f"{lon:.4f}",
        "start_date": "2011-01-01",
        "end_date": "2020-12-31",
        "daily": "temperature_2m_max,temperature_2m_min",
        "timezone": "auto",
    }
    data = http_util.get_json(_url(ARCHIVE_URL, params))
    daily = data.get("daily") or {}
    times = daily.get("time") or []
    tmax = daily.get("temperature_2m_max") or []
    tmin = daily.get("temperature_2m_min") or []
    gdaily = [gdd_f(tmax[i] if i < len(tmax) else None,
                    tmin[i] if i < len(tmin) else None) for i in range(len(times))]
    clim = _doy_climatology({"time": times, "gdd_daily": gdaily}, ["gdd_daily"])
    smoothed = clim["gdd_daily"]
    gdd = [round(smoothed[d], 2) if smoothed[d] is not None else 0.0 for d in range(367)]
    if times:  # don't freeze an empty archive response forever
        cache.set_json(key, gdd)
    return gdd


def gdd_by_year(lat, lon, y0, y1, start_month):
    """Cumulative corn GDD by date for each year in [y0, y1], from ``start_month``.

    One ERA5 archive call for the whole span; accumulation resets each year at
    ``start_month``. Returns {"dates": [MM-DD...], "years": {str(y): [cum...]}}
    aligned on a shared MM-DD grid, or None. Historical -> cached permanently.
    """
    key = f"gddyr:{round(lat, 2)}:{round(lon, 2)}:{y0}:{y1}:{start_month}"
    cached = cache.get_json(key)
    if cached is not None:
        return cached
    params = {"latitude": f"{lat:.4f}", "longitude": f"{lon:.4f}",
              "start_date": f"{y0}-{start_month:02d}-01", "end_date": f"{y1}-12-31",
              "daily": "temperature_2m_max,temperature_2m_min", "timezone": "auto"}
    data = http_util.get_json(_url(ARCHIVE_URL, params))
    daily = data.get("daily") or {}
    times = daily.get("time") or []
    tmax = daily.get("temperature_2m_max") or []
    tmin = daily.get("temperature_2m_min") or []
    if not times:
        return None
    per_year, acc = {}, {}
    for i, t in enumerate(times):
        try:
            d = datetime.date.fromisoformat(t)
        except (ValueError, TypeError):
            continue
        if d.month < start_month:  # season only, from start_month onward
            continue
        g = gdd_f(tmax[i] if i < len(tmax) else None, tmin[i] if i < len(tmin) else None)
        acc[d.year] = acc.get(d.year, 0.0) + g
        if d.month != 2 or d.day != 29:  # drop Feb-29 so years align on a common MM-DD grid
            per_year.setdefault(d.year, {})[t[5:]] = round(acc[d.year])
    if not per_year:
        return None
    all_dates = sorted({md for yd in per_year.values() for md in yd})
    result = {"dates": all_dates,
              "years": {str(y): [per_year[y].get(md) for md in all_dates] for y in sorted(per_year)}}
    cache.set_json(key, result)
    return result


def _month_end(d):
    nxt = datetime.date(d.year + (d.month == 12), d.month % 12 + 1, 1)
    return nxt - datetime.timedelta(days=1)


def _gdd_daily_window(lat, lon, times, tmax, tmin, until=None):
    """Zip an API daily block into aligned (date_str, gdd) pairs."""
    out = []
    for i, t in enumerate(times):
        if until and t > until:
            break
        if i >= len(tmax) or i >= len(tmin) or tmax[i] is None or tmin[i] is None:
            continue
        out.append((t, gdd_f(tmax[i], tmin[i])))
    return out


def gdd_series(lat, lon, start_date, end_date):
    """Cumulative GDD (actual vs normal) from start_date to today.

    Long seasons are SPLIT: the immutable early part comes from ONE archive call
    cached under a month-stable key (so the rate-limited archive is hit roughly
    once a month, not daily — the old end-date-keyed cache never hit across days
    and re-pulled the whole span from the archive every single day), and the last
    ~1-2 months come from the forecast endpoint's past_days (never rate-limited).
    """
    key = f"gdd:{round(lat, 2)}:{round(lon, 2)}:{start_date}:{end_date}"
    cached = cache.get_json(key)
    if cached is not None:
        return cached

    start = datetime.date.fromisoformat(start_date)
    end = datetime.date.fromisoformat(end_date)
    full_past = (end - start).days
    if full_past < 1:
        return None

    # The normal needs the (rate-limited) archive; if it's unavailable we still
    # show actual accumulation and fill the normal in on a later run.
    try:
        gnorm = gdd_normal(lat, lon)
    except Exception:
        gnorm = None

    base = {"latitude": f"{lat:.4f}", "longitude": f"{lon:.4f}",
            "daily": "temperature_2m_max,temperature_2m_min", "timezone": "auto"}
    daily_gdd = []   # [(date_str, gdd)]
    if full_past <= 92:
        # short season: the forecast endpoint covers all of it in one cheap call
        params = dict(base, past_days=str(full_past), forecast_days="1")
        data = http_util.get_json(_url(FORECAST_URL, params))
        d = data.get("daily") or {}
        daily_gdd = _gdd_daily_window(lat, lon, d.get("time") or [],
                                      d.get("temperature_2m_max") or [],
                                      d.get("temperature_2m_min") or [], until=end_date)
    else:
        # pre_end = last day of the month ~2 months back: stable within a month
        # (cache key only changes monthly) and always leaves a 31-61 day tail <= 92
        pre_end = _month_end(end - datetime.timedelta(days=61))
        pre_key = f"gddpre:{round(lat, 2)}:{round(lon, 2)}:{start_date}:{pre_end.isoformat()}"
        pre = cache.get_json(pre_key)
        if pre is None:
            params = dict(base, start_date=start_date, end_date=pre_end.isoformat())
            data = http_util.get_json(_url(ARCHIVE_URL, params))
            d = data.get("daily") or {}
            pre = _gdd_daily_window(lat, lon, d.get("time") or [],
                                    d.get("temperature_2m_max") or [],
                                    d.get("temperature_2m_min") or [])
            # this branch only runs when the season is >92 days old, so an empty or
            # late-starting pre-chunk is ALWAYS a degraded response (proxy 200-with-
            # no-body), never a young season. Publishing just the <=61-day tail would
            # undercount months of GDD AND block the carry-over (res['gdd'] truthy).
            if not pre or pre[0][0] > start_date:
                return None
            cache.set_json(pre_key, pre)   # immutable history, past the archive lag
        # tail from the forecast endpoint (includes today); drop the overlap day
        tail_days = (end - pre_end).days
        params = dict(base, past_days=str(min(tail_days, 92)), forecast_days="1")
        data = http_util.get_json(_url(FORECAST_URL, params))
        d = data.get("daily") or {}
        tail = _gdd_daily_window(lat, lon, d.get("time") or [],
                                 d.get("temperature_2m_max") or [],
                                 d.get("temperature_2m_min") or [], until=end_date)
        pe = pre_end.isoformat()
        daily_gdd = [(t, g) for t, g in (pre or [])] + [(t, g) for t, g in tail if t > pe]

    dates, actual_cum, normal_cum = [], [], []
    acc = nacc = 0.0
    for t, g in daily_gdd:
        acc += g
        dates.append(t)
        actual_cum.append(round(acc))
        if gnorm:
            try:
                nacc += gnorm[_doy(t)] or 0.0
            except (ValueError, IndexError, TypeError):
                pass
            normal_cum.append(round(nacc))
        else:
            normal_cum.append(None)

    if not dates:
        return None
    td = actual_cum[-1]
    ntd = normal_cum[-1] if gnorm else None
    result = {
        "dates": [d[5:] for d in dates],
        "actual_cum": actual_cum,
        "normal_cum": normal_cum,
        "to_date": td,
        "normal_to_date": ntd,
        "pct_of_normal": round(td / ntd * 100) if ntd else None,
        "through": dates[-1],
    }
    # Cache permanently ONLY when the series is complete: it has the normal AND
    # actually begins at the labeled season start (never freeze a truncated or
    # normal-less result — a later run can then fix it).
    if gnorm and dates[0] <= start_date:
        cache.set_json(key, result)
    return result


_MONTH_NAMES = {1: "Jan", 2: "Feb", 3: "Mar", 4: "Apr", 5: "May", 6: "Jun",
                7: "Jul", 8: "Aug", 9: "Sep", 10: "Oct", 11: "Nov", 12: "Dec"}


def _normal_month(norm, months):
    """Aggregate per-DOY normals into {month: (precip_total, temp_mean)}."""
    out = {}
    if not norm:
        return out
    tarr = norm.get("temp") or []
    parr = norm.get("precip") or []
    for m in months:
        tv, pv, phas = [], 0.0, False
        for day in range(1, 32):
            try:
                doy = datetime.date(2021, m, day).timetuple().tm_yday  # 2021 = non-leap
            except ValueError:
                break
            if doy < len(tarr) and tarr[doy] is not None:
                tv.append(tarr[doy])
            if doy < len(parr) and parr[doy] is not None:
                pv += parr[doy]
                phas = True
        out[m] = (round(pv, 1) if phas else None,
                  round(sum(tv) / len(tv), 1) if tv else None)
    return out


def monthly_climate(lat, lon, year, today, norm, months=(6, 7, 8, 9)):
    """Observed monthly precip total + mean temp for ``year`` vs the 1991-2020
    normal (item 16). One archive call for the season-to-date, cached by end date
    so it refreshes as months fill in."""
    end = today.isoformat() if hasattr(today, "isoformat") else str(today)
    obs_p, obs_t = {}, {}
    key = f"climobs:{round(lat, 2)}:{round(lon, 2)}:{year}:{end}"
    last_obs = None   # last date the archive actually had data for (it lags ~5 days)
    cached = cache.get_json(key)
    if cached is not None:
        obs_p = {int(k): v for k, v in cached["p"].items()}
        obs_t = {int(k): v for k, v in cached["t"].items()}
        last_obs = cached.get("last_obs")
    else:
        params = {"latitude": f"{lat:.4f}", "longitude": f"{lon:.4f}",
                  "start_date": f"{year}-{min(months):02d}-01", "end_date": end,
                  "daily": "temperature_2m_mean,precipitation_sum", "timezone": "auto"}
        data = http_util.get_json(_url(ARCHIVE_URL, params))
        daily = data.get("daily") or {}
        times = daily.get("time") or []
        tt = daily.get("temperature_2m_mean") or []
        pp = daily.get("precipitation_sum") or []
        pacc, tacc = {}, {}
        for i, ts in enumerate(times):
            try:
                d = datetime.date.fromisoformat(ts)
            except (ValueError, TypeError):
                continue
            if i < len(pp) and pp[i] is not None:
                pacc[d.month] = pacc.get(d.month, 0.0) + pp[i]
                last_obs = max(last_obs or ts, ts)
            if i < len(tt) and tt[i] is not None:
                tacc.setdefault(d.month, []).append(tt[i])
                last_obs = max(last_obs or ts, ts)
        obs_p = {m: round(v, 1) for m, v in pacc.items()}
        obs_t = {m: round(sum(v) / len(v), 1) for m, v in tacc.items() if v}
        if obs_p or obs_t:  # don't freeze an empty/partial archive result for the day
            cache.set_json(key, {"p": {str(k): v for k, v in obs_p.items()},
                                 "t": {str(k): v for k, v in obs_t.items()},
                                 "last_obs": last_obs})
    nmon = _normal_month(norm, months)
    # the in-progress month holds only month-to-date observations — flag it so the
    # UI never compares a few days of precip against a FULL-month normal (which
    # painted a fake deficit for most of every month)
    tday = today if hasattr(today, "month") else datetime.date.fromisoformat(str(today))
    rows = []
    for m in months:
        np_, nt_ = nmon.get(m, (None, None))
        row = {"month": _MONTH_NAMES.get(m, str(m)),
               "precip": obs_p.get(m), "precip_normal": np_,
               "temp": obs_t.get(m), "temp_normal": nt_}
        if tday.year == year and m == tday.month:
            row["mtd"] = True
            row["mtd_days"] = tday.day
        elif last_obs and row["precip"] is not None:
            # a COMPLETED month whose observations stop early (the ~5-day archive
            # lag right after month-end) is also partial — must not be compared to
            # a full-month normal as if complete
            mend = _month_end(datetime.date(year, m, 1)).isoformat()
            if last_obs < mend:
                row["mtd"] = True
                try:
                    row["mtd_days"] = int(last_obs[8:10])
                except (ValueError, TypeError):
                    pass
        rows.append(row)
    return {"year": year, "rows": rows}


def weather_anomaly(forecast, norm):
    """Forecast-minus-normal anomalies grouped into days 1-5 / 6-10 / 11-15 / 1-15."""
    daily = forecast.get("daily") or {}
    times = daily.get("time") or []
    temps = daily.get("temperature_2m_mean") or []
    precs = daily.get("precipitation_sum") or []
    if len(times) < 15 or not norm:
        return None

    windows = [(0, 5), (5, 10), (10, 15), (0, 15)]
    temp_out, precip_mm_out, precip_pct_out = [], [], []
    for start, end in windows:
        t_anoms, f_prec, n_prec = [], 0.0, 0.0
        for i in range(start, end):
            try:
                d = _doy(times[i])
            except (ValueError, IndexError, TypeError):
                continue
            tn = norm["temp"][d]
            pn = norm["precip"][d]
            if i < len(temps) and temps[i] is not None and tn is not None:
                t_anoms.append(temps[i] - tn)
            # sum forecast and normal precip over the SAME days, else the ratio is biased
            if i < len(precs) and precs[i] is not None and pn is not None:
                f_prec += precs[i]
                n_prec += pn
        temp_out.append(round(sum(t_anoms) / len(t_anoms), 2) if t_anoms else None)
        precip_mm_out.append(round(f_prec - n_prec, 1))
        precip_pct_out.append(round(f_prec / n_prec * 100, 0) if n_prec > 0 else None)

    return {
        "windows": ["1-5 d", "6-10 d", "11-15 d", "1-15 d"],
        "temp": temp_out,
        "precip_mm": precip_mm_out,
        "precip_pct": precip_pct_out,
    }
