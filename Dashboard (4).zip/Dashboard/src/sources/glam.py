"""GLAM NDVI client (NASA Harvest "GLAM API v2", https://api.glamdata.org).

State-level, corn-masked NDVI. No API key. Standard library only.

Notes from live testing:
- Trailing slashes are REQUIRED on every path.
- In /query/{product}/{date}/{cropmask}/{boundary_layer}/{feature_id}/ the
  boundary_layer is the boundary id (geoboundaries-usa-adm1), NOT "ndvi".
- Past 8-day composites are immutable -> cached forever, so only new composites
  are fetched on later runs (keeps "update every run" fast after the first build).
"""
import datetime
import urllib.parse

import cache
import http_util

BASE = "https://api.glamdata.org"
CROPMASK = "geoglam-bacs-maize"
BOUNDARY = "geoboundaries-usa-adm1"


def feature_map():
    """{state_name: feature_id} for US states (cached; rarely changes)."""
    cached = cache.get_json("glam:feature_map")
    if cached is not None:
        return cached
    url = f"{BASE}/boundary-features/{BOUNDARY}/"
    arr = http_util.get_json(url)
    fmap = {}
    for item in arr:
        name = item.get("feature_name")
        fid = item.get("feature_id")
        if name and fid is not None:
            fmap[name] = fid
    if fmap:
        cache.set_json("glam:feature_map", fmap)
    return fmap


def _doy(date_str):
    return datetime.date.fromisoformat(date_str).timetuple().tm_yday


_run_memo = {}   # process-lifetime memo for non-cacheable listings: the current-season
                 # composite list is byte-identical for every state, so one run was
                 # fetching it 49 times (fresh day-to-day is preserved — memory only)


def _composites(product, d0, d1, cacheable):
    """Return sorted [(date_str, doy, prelim)] for ``product`` in [d0, d1]."""
    key = f"glam:dates:{product}:{d0}:{d1}"
    if cacheable:
        hit = cache.get_json(key)
        if hit is not None:
            return [tuple(x) for x in hit]
    elif key in _run_memo:
        return _run_memo[key]

    url = (f"{BASE}/datasets/?date_after={d0}&date_before={d1}"
           f"&product={urllib.parse.quote(product)}")
    out = []
    pages = 0
    while url and pages < 12:
        obj = http_util.get_json(url)
        for r in obj.get("results", []):
            if r.get("product_id") != product:
                continue
            ds = r.get("date")
            if not ds:
                continue
            try:
                out.append((ds, _doy(ds), bool(r.get("prelim"))))
            except (ValueError, TypeError):
                continue
        url = obj.get("next")
        pages += 1
    out.sort(key=lambda t: t[0])
    if cacheable:
        cache.set_json(key, out)
    else:
        _run_memo[key] = out
    return out


def _query_mean(product, date_str, feature_id, cacheable):
    key = f"glam:ndvi:{product}:{date_str}:{CROPMASK}:{feature_id}"
    if cacheable:
        hit = cache.get_json(key)
        if hit is not None:
            return hit.get("mean")
    url = (f"{BASE}/query/{product}/{date_str}/{CROPMASK}/"
           f"{BOUNDARY}/{feature_id}/")
    try:
        obj = http_util.get_json(url)
    except http_util.HttpError:
        return None
    mean = obj.get("mean")
    if mean is None:
        return None
    # GLAM occasionally returns 'NaN'/non-numeric; float('NaN') would become a bare
    # NaN token in the JSON and make the browser's JSON.parse throw -> blank dashboard.
    try:
        mean = float(mean)
    except (TypeError, ValueError):
        return None
    if mean != mean or mean in (float("inf"), float("-inf")):  # NaN / Inf
        return None
    mean = round(mean, 3)
    if cacheable:
        cache.set_json(key, {"mean": mean})
    return mean


def _nearest(doy_map, doy, tol=4):
    if doy in doy_map:
        return doy_map[doy]
    best, best_d = None, tol + 1
    for k, v in doy_map.items():
        d = abs(k - doy)
        if d < best_d:
            best, best_d = v, d
    return best


def late_ndvi_by_year(cfg, feature_id, y0, y1, target_doy=225):
    """Late-season corn-masked NDVI (one value per year) for the regression panel.

    Picks the single 8-day composite nearest ``target_doy`` (~Aug 13, peak
    grain-fill) each year — one NDVI query per year instead of averaging the
    whole month, so the first build stays fast. Composite dates and means are
    cached, so repeat runs cost nothing.
    """
    if feature_id is None:
        return {}
    product = cfg["ndvi_product"]
    out = {}
    for yr in range(y0, y1 + 1):
        # a 3-week window around the target covers it with a couple composites
        comps = _composites(
            product,
            datetime.date(yr, 7, 25).isoformat(),
            datetime.date(yr, 9, 5).isoformat(),
            cacheable=True,
        )
        if not comps:
            continue
        ds, _doy_v, prelim = min(comps, key=lambda c: abs(c[1] - target_doy))
        v = _query_mean(product, ds, feature_id, cacheable=not prelim)
        if v is not None:
            out[yr] = v
    return out


def ndvi_for_state(cfg, feature_id, today=None):
    """Corn-masked NDVI for the current season with a prior-years baseline+anomaly."""
    if feature_id is None:
        return None
    product = cfg["ndvi_product"]
    start_month = int(cfg["ndvi_season_start_month"])
    baseline_years = int(cfg["ndvi_baseline_years"])
    max_comp = int(cfg["ndvi_max_composites"])
    today = today or datetime.date.today()

    season_start = datetime.date(today.year, start_month, 1)
    if today < season_start:
        # before this year's season: show last year's full season instead
        today = datetime.date(today.year - 1, 12, 31)
        season_start = datetime.date(today.year, start_month, 1)

    cur = _composites(product, season_start.isoformat(), today.isoformat(), cacheable=False)
    cur = cur[-max_comp:]
    if not cur:
        return None

    dates, values = [], []
    for ds, _doy_v, prelim in cur:
        v = _query_mean(product, ds, feature_id, cacheable=not prelim)
        dates.append(ds)
        values.append(v)

    baseline = [None] * len(cur)
    year_series = {}  # prior year -> [value per current composite]
    if baseline_years > 0:
        for k in range(1, baseline_years + 1):
            year_series[today.year - k] = [None] * len(cur)
        doy_maps = {}
        for k in range(1, baseline_years + 1):
            by = today.year - k
            end_day = today.day
            if today.month == 2 and today.day == 29:  # clamp Feb-29 for non-leap baseline years
                try:
                    datetime.date(by, 2, 29)
                except ValueError:
                    end_day = 28
            comps = _composites(
                product,
                datetime.date(by, start_month, 1).isoformat(),
                datetime.date(by, today.month, end_day).isoformat(),
                cacheable=True,
            )
            # keep the prelim flag: a preliminary composite's mean must NOT be frozen
            # into the permanent cache (the finalized value can differ)
            doy_maps[by] = {doy: (ds, p) for ds, doy, p in comps}
        for idx, (ds, doy_v, _p) in enumerate(cur):
            bvals = []
            for k in range(1, baseline_years + 1):
                by = today.year - k
                hit = _nearest(doy_maps.get(by, {}), doy_v)
                if hit:
                    bds, bprelim = hit
                    bv = _query_mean(product, bds, feature_id, cacheable=not bprelim)
                    if bv is not None:
                        bvals.append(bv)
                        year_series[by][idx] = bv
            if bvals:
                baseline[idx] = round(sum(bvals) / len(bvals), 3)

    anomaly = [
        round(v - b, 3) if (v is not None and b is not None) else None
        for v, b in zip(values, baseline)
    ]

    if not any(v is not None for v in values):
        return None

    # ---- year-round (Jan 1 – Dec 31) multi-year evolution, DOY-aligned ----
    # Comparable prior years run the whole calendar year so the full annual NDVI
    # curve (flat winter → green-up → peak → senescence) is visible; the current
    # year is drawn from its season-to-date data (starts at green-up). The bare-soil
    # off-season carries little signal, so it's sampled sparsely (~every 10 weeks) to
    # keep the fetch light while the growing season stays 8-day dense. VIIRS composites
    # sit on a fixed DOY grid, so years align by DOY.
    n_evo = int(cfg.get("ndvi_evolution_years", 3))
    cur_doy_val = {doy: v for (ds, doy, _p), v in zip(cur, values) if v is not None}
    evo = {today.year: cur_doy_val}
    all_doys = set(cur_doy_val)

    def _keep(doy):
        return (91 <= doy <= 288) or (doy % 72 < 8)  # dense in-season, sparse off-season

    for k in range(1, n_evo + 1):
        y = today.year - k
        comps = _composites(product, datetime.date(y, 1, 1).isoformat(),
                            datetime.date(y, 12, 31).isoformat(), cacheable=True)
        dd = {}
        for ds, doy, prelim in comps:
            if not _keep(doy):
                continue
            mv = _query_mean(product, ds, feature_id, cacheable=not prelim)
            if mv is not None:
                dd[doy] = mv
                all_doys.add(doy)
        evo[y] = dd
    doys = sorted(all_doys)
    evo_prior = [today.year - k for k in range(1, n_evo + 1)]
    band_min, band_max = [], []
    for doy in doys:
        colv = [evo[y][doy] for y in evo_prior if doy in evo[y]]
        band_min.append(round(min(colv), 3) if colv else None)
        band_max.append(round(max(colv), 3) if colv else None)

    def _evo_label(doy):
        return (datetime.date(today.year, 1, 1) + datetime.timedelta(days=doy - 1)).strftime("%m-%d")

    evolution = {
        "dates": [_evo_label(doy) for doy in doys],
        "current": [evo[today.year].get(doy) for doy in doys],
        "current_year": today.year,
        "years": {str(y): [evo[y].get(doy) for doy in doys] for y in evo_prior + [today.year]},
        "band_min": band_min,
        "band_max": band_max,
    }

    label = "VIIRS" if product.startswith("vnp") else "MODIS"
    return {
        "dates": [d[5:] for d in dates],
        "values": values,
        "baseline": baseline,
        "anomaly": anomaly,
        "evolution": evolution,
        "source": f"GLAM {label} NDVI (corn-masked)",
        "baseline_years": baseline_years,
    }
