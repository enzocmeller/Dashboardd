"""Load configuration from config.json with sensible defaults and env overrides.

Pure standard library. The only required setting is ``nass_api_key``.
"""
import json
import os

# Project root = parent of this file's directory (src/..)
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

DEFAULTS = {
    "nass_api_key": "",
    "states": "all",
    "yield_start_year": 1990,
    "condition_history_years": 12,
    "ndvi_product": "vnp09h1-ndvi",
    "ndvi_season_start_month": 4,
    "ndvi_baseline_years": 2,
    "ndvi_evolution_years": 3,
    "ndvi_max_composites": 24,
    "gdd_start_month": 1,
    "gdd_evolution_years": 3,
    "regression_start_year": 2008,
    "top_counties_for_centroid": 15,
    "request_delay_seconds": 0.3,
    "request_timeout_seconds": 60,
    "request_retries": 3,
    "ca_bundle": "",
}


class ConfigError(Exception):
    pass


def load(path=None):
    """Read config.json (if present), layer it over defaults, apply env overrides."""
    cfg = dict(DEFAULTS)
    path = path or os.path.join(ROOT, "config.json")
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8-sig") as fh:
                user = json.load(fh)
        except json.JSONDecodeError as exc:
            raise ConfigError(f"config.json is not valid JSON: {exc}")
        for key, value in user.items():
            if key.startswith("_"):
                continue
            cfg[key] = value

    # Coerce known numeric knobs up front: a non-numeric value should be ONE clear
    # ConfigError, not 49 cryptic per-state failures deep inside the run.
    _INT_KEYS = ("yield_start_year", "condition_history_years", "ndvi_season_start_month",
                 "ndvi_baseline_years", "ndvi_evolution_years", "ndvi_max_composites",
                 "gdd_start_month", "gdd_evolution_years", "regression_start_year",
                 "top_counties_for_centroid", "request_timeout_seconds", "request_retries")
    _FLOAT_KEYS = ("request_delay_seconds",)
    for k in _INT_KEYS:
        try:
            cfg[k] = int(cfg[k])
        except (TypeError, ValueError):
            raise ConfigError(f"config.json: '{k}' must be an integer (got {cfg[k]!r})")
    for k in _FLOAT_KEYS:
        try:
            cfg[k] = float(cfg[k])
        except (TypeError, ValueError):
            raise ConfigError(f"config.json: '{k}' must be a number (got {cfg[k]!r})")

    # Environment overrides (handy on locked-down machines / CI)
    if os.environ.get("NASS_API_KEY"):
        cfg["nass_api_key"] = os.environ["NASS_API_KEY"]
    if os.environ.get("SSL_CERT_FILE") and not cfg.get("ca_bundle"):
        cfg["ca_bundle"] = os.environ["SSL_CERT_FILE"]

    cfg["root"] = ROOT
    cfg["data_dir"] = os.path.join(ROOT, "data")
    return cfg


def require_nass_key(cfg):
    key = (cfg.get("nass_api_key") or "").strip()
    if not key or key.upper().startswith("PASTE_"):
        raise ConfigError(
            "No USDA NASS API key found.\n"
            "  1. Get a free key (instant) at: https://quickstats.nass.usda.gov/api\n"
            "  2. Copy config.example.json to config.json\n"
            "  3. Paste your key into the \"nass_api_key\" field.\n"
            "  (or set the NASS_API_KEY environment variable)"
        )
    return key
