"""Assemble the self-contained index.html by inlining ECharts + GeoJSON + data.

The result is a single file that opens directly from file:// with zero network
calls — the firewall-friendly deliverable.
"""
import json
import math
import os
import time


def _finite(obj):
    """Recursively replace NaN/Inf floats with None so the inlined JSON is always
    valid (a bare NaN token would make the browser's JSON.parse throw and blank the
    whole file:// dashboard). Guarantees a parseable page without crashing the build.
    """
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if isinstance(obj, dict):
        return {k: _finite(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_finite(v) for v in obj]
    return obj


def _read(path, label):
    if not os.path.exists(path):
        raise FileNotFoundError(f"Missing {label}: {path}")
    with open(path, "r", encoding="utf-8") as fh:
        return fh.read()


def _safe(text):
    """Prevent an embedded '</script>' (or '<!--') from breaking the page."""
    return text.replace("</", "<\\/").replace("<!--", "<\\!--")


# Far-flung regions dropped from the MAP so the continental US fills the frame
# (they shrink the projection). Hawaii/Puerto Rico stay selectable via the dropdown;
# Alaska is excluded from the dashboard entirely (absent from src/states.py).
_MAP_EXCLUDE = {"Alaska", "Hawaii", "Puerto Rico"}


def render(cfg, payload):
    root = cfg["root"]
    template = _read(os.path.join(root, "templates", "dashboard.html"), "template")
    echarts = _read(os.path.join(root, "assets", "echarts.min.js"), "echarts.min.js")
    geojson = _read(os.path.join(root, "src", "geo", "us_states.geo.json"), "us_states.geo.json")

    geo = json.loads(geojson)
    geo["features"] = [f for f in geo.get("features", [])
                       if (f.get("properties") or {}).get("name") not in _MAP_EXCLUDE]

    data_json = _safe(json.dumps(_finite(payload), ensure_ascii=False, separators=(",", ":")))
    geo_json = _safe(json.dumps(geo, ensure_ascii=False, separators=(",", ":")))

    html = template.replace("/*__ECHARTS__*/", echarts)
    html = html.replace("/*__GEOJSON__*/", geo_json)
    html = html.replace("/*__DATA__*/", data_json)

    # atomic replace: a kill/sync race must never leave a truncated index.html;
    # short retry because OneDrive/AV can briefly lock files in the synced folder
    out = os.path.join(root, "index.html")
    tmp = out + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(html)
    for i in range(5):
        try:
            os.replace(tmp, out)
            break
        except PermissionError:
            if i == 4:
                raise
            time.sleep(0.5 * (i + 1))
    return out
