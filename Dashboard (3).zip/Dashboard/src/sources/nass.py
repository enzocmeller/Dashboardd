"""USDA NASS Quick Stats client (corn). Standard library only.

Single host: https://quickstats.nass.usda.gov/api  (HTTPS/443, key required).
Per-state queries are small (well under the 50,000-row cap), so we query one
state at a time and never need paging.
"""
import datetime
import http.client
import urllib.error
import urllib.parse

import cache
import http_util

BASE = "https://quickstats.nass.usda.gov/api/api_GET/"

COMMON = {
    "source_desc": "SURVEY",
    "sector_desc": "CROPS",
    "commodity_desc": "CORN",
    "format": "JSON",
}


class NassAuthError(Exception):
    pass


def _scope(state_alpha):
    """STATE+state filter, or NATIONAL when state_alpha is None (US-wide)."""
    if state_alpha:
        return {"agg_level_desc": "STATE", "state_alpha": state_alpha}
    return {"agg_level_desc": "NATIONAL"}


def _build_url(key, params):
    q = {"key": key}
    q.update(COMMON)
    q.update(params)
    # NASS wants spaces/commas literally encoded; urlencode with quote_via handles it.
    return BASE + "?" + urllib.parse.urlencode(q, quote_via=urllib.parse.quote)


def _api_get(key, params):
    """Return the list of records, or [] when nothing matches the query."""
    url = _build_url(key, params)
    try:
        obj = http_util.get_json(url)
    except http_util.HttpError as exc:
        body = str(exc).lower()
        if exc.status == 401 or "unauthorized" in body or "api key" in body:
            raise NassAuthError(
                "USDA NASS rejected the API key (401/unauthorized). "
                "Check nass_api_key in config.json."
            )
        # 400 with no matching records is normal for sparse states.
        return []
    except (urllib.error.URLError, OSError, ValueError, http.client.HTTPException):
        # A raw network error (URLError/Timeout/Connection are OSError subclasses), a
        # proxy block-page that isn't JSON (JSONDecodeError is a ValueError), or a
        # truncated response (IncompleteRead/BadStatusLine are HTTPException, which is
        # NOT an OSError) must degrade to "no rows" — one dropped request must never
        # abort a whole state, and from all_state_production it would kill the run.
        return []
    if isinstance(obj, dict):
        if "data" in obj:
            return obj["data"]
        if "error" in obj:
            return []
    return []


# ----------------------------------------------------------------------------
# value parsing
# ----------------------------------------------------------------------------
def _num(value):
    """Parse a NASS Value string. Suppressed markers -> None."""
    if value is None:
        return None
    s = str(value).strip().replace(",", "")
    if not s or s.startswith("(") or s.upper() in ("", "NA", "D", "Z"):
        return None
    try:
        return float(s)
    except ValueError:
        return None


def _week_num(week_ending):
    """ISO week number from a YYYY-MM-DD week_ending date (for cross-year align)."""
    try:
        d = datetime.date.fromisoformat(week_ending)
        return d.isocalendar()[1]
    except (ValueError, TypeError):
        return None


def _condition_cat(short_desc):
    s = (short_desc or "").upper()
    if "VERY POOR" in s:
        return "very_poor"
    if "EXCELLENT" in s:
        return "excellent"
    if "GOOD" in s:
        return "good"
    if "FAIR" in s:
        return "fair"
    if "POOR" in s:
        return "poor"
    return None


def _progress_stage(short_desc):
    s = (short_desc or "").upper()
    if "PLANTED" in s:
        return "planted"
    if "SILKING" in s:
        return "silking"
    if "DOUGH" in s:
        return "dough"
    if "MATURE" in s:
        return "mature"
    return None


# ----------------------------------------------------------------------------
# panels 3: phenology (current snapshot)
# ----------------------------------------------------------------------------
def phenology(key, usps, year):
    params = {"statisticcat_desc": "PROGRESS", "year": str(year)}
    params.update(_scope(usps))
    rows = _api_get(key, params)
    latest = {}   # stage -> (week_ending, value)
    for r in rows:
        stage = _progress_stage(r.get("short_desc"))
        if not stage:
            continue
        wk = r.get("week_ending")
        val = _num(r.get("Value"))
        if wk is None or val is None:
            continue
        if stage not in latest or wk > latest[stage][0]:
            latest[stage] = (wk, val)
    if not latest:
        return None
    as_of = max(v[0] for v in latest.values())
    return {
        "as_of": as_of,
        "planted": latest.get("planted", (None, None))[1],
        "silking": latest.get("silking", (None, None))[1],
        "dough": latest.get("dough", (None, None))[1],
        "mature": latest.get("mature", (None, None))[1],
    }


def progress_history(key, usps, start_year, last_complete=None):
    """{year: {stage: {iso_week(str): pct}}} for every PROGRESS stage — feeds the
    'vs 5-yr average' comparison on the phenology panel ("silking 45% vs 52% avg"
    is the most quoted line in every Monday writeup). Completed years are immutable,
    so with ``last_complete`` set they serve from the permanent cache."""
    if last_complete is not None:
        return _cached_history("prog", usps, start_year, last_complete,
                               lambda: progress_history(key, usps, start_year))
    params = {"statisticcat_desc": "PROGRESS", "year__GE": str(start_year)}
    params.update(_scope(usps))
    out = {}
    for r in _api_get(key, params):
        stage = _progress_stage(r.get("short_desc"))
        wk = r.get("week_ending")
        val = _num(r.get("Value"))
        if not stage or not wk or val is None:
            continue
        w = _week_num(wk)
        if w is None:
            continue
        out.setdefault(int(wk[:4]), {}).setdefault(stage, {})[str(w)] = val
    return out


def progress_5yr_avg(hist, stage, iso_week, tol=1):
    """Average a stage's % at (or within ±tol of) ``iso_week`` across the years in
    ``hist`` (nearest week per year). None with fewer than 3 contributing years.
    Early-season nuance: a year with no row at that week but rows LATER in the
    season means the stage hadn't started (counts as 0), not missing data."""
    vals = []
    for _y, stages in (hist or {}).items():
        wkmap = (stages or {}).get(stage) or {}
        best, best_d = None, tol + 1
        for w_s, v in wkmap.items():
            try:
                d = abs(int(w_s) - iso_week)
            except (TypeError, ValueError):
                continue
            if d < best_d:
                best, best_d = v, d
        if best is not None:
            vals.append(best)
        elif wkmap:
            try:
                if min(int(w) for w in wkmap) > iso_week:
                    vals.append(0.0)   # reporting starts when the stage starts
            except (TypeError, ValueError):
                pass
    if len(vals) < 3:
        return None
    return round(sum(vals) / len(vals), 1)


# ----------------------------------------------------------------------------
# soil moisture (USDA weekly farmer survey: Very Short / Short / Adequate / Surplus)
# This is the GROUND-TRUTH "is it wet or dry" signal — the same numbers ag reports
# quote ("Illinois 39% surplus") — reported weekly, keyed+allowlisted (no archive
# quota). It complements the Open-Meteo *model* soil forecast (which gives the
# 10-day trajectory but, as an absolute volumetric %, can't tell "wet for this
# soil" from "dry for this soil" and understated wet-climate states like Illinois).
# ----------------------------------------------------------------------------
def _cached_history(kind, usps, start_year, last_complete, producer):
    """Permanent cache for IMMUTABLE completed-year NASS history (regression
    predictors). The key embeds ``last_complete`` (the last finished crop year), so
    it self-refreshes exactly once when the year rolls over. Current-year rows are
    dropped before caching — live in-season data is never frozen. This removes the
    3 heaviest recurring NASS pulls per state (~130 calls/run) after the first run."""
    ckey = f"nasshist:{kind}:{usps or 'US'}:{start_year}:{last_complete}"
    hit = cache.get_json(ckey)
    if hit is not None:
        return {int(k): v for k, v in hit.items()}
    full = producer() or {}
    trimmed = {y: v for y, v in full.items() if isinstance(y, int) and y <= last_complete}
    if trimmed:
        cache.set_json(ckey, {str(k): v for k, v in trimmed.items()})
    return trimmed


_SOIL_CATS = ("very_short", "short", "adequate", "surplus")


def _soil_layer(short_desc):
    s = (short_desc or "").upper()
    if "PREVIOUS YEAR" in s:            # skip the year-ago comparison rows
        return None
    if "TOPSOIL" in s:
        return "topsoil"
    if "SUBSOIL" in s:
        return "subsoil"
    return None


def _soil_cat(unit_desc):
    u = (unit_desc or "").upper()
    if "VERY SHORT" in u:               # check before plain SHORT (substring)
        return "very_short"
    if "SHORT" in u:
        return "short"
    if "ADEQUATE" in u:
        return "adequate"
    if "SURPLUS" in u:
        return "surplus"
    return None


def _soil_status(cats):
    """Headline wet/dry label from the VS/S/A/Surplus split. Most states sit at
    "Adequate" (the usual majority); we only escalate to "Surplus" or "Short" when a
    SUBSTANTIAL share of fields is actually wet/dry AND that lean dominates — so a
    state that's, say, 74% adequate + 26% short reads "Adequate", not "Short"."""
    if not cats or any(cats.get(k) is None for k in _SOIL_CATS):
        return None
    short = cats["very_short"] + cats["short"]        # dry share
    surplus = cats["surplus"]                          # wet share
    if surplus >= 30 and surplus > short:
        label = "Surplus"
    elif short >= 35 and short > surplus:
        label = "Short"
    else:
        label = "Adequate"
    return {"short_pct": short, "adequate_pct": cats["adequate"],
            "surplus_pct": surplus, "balance": surplus - short, "label": label}


def topsoil_moisture(key, usps, year):
    """Latest-week USDA topsoil (+ subsoil) moisture split for the CURRENT crop
    year. Returns None when the state has no current-year soil survey (many
    non-Corn-Belt states don't report it) — never a stale prior-year row.
    """
    params = {"commodity_desc": "SOIL", "statisticcat_desc": "MOISTURE", "year": str(year)}
    params.update(_scope(usps))
    rows = _api_get(key, params)
    by_layer = {"topsoil": {}, "subsoil": {}}   # layer -> week -> {cat: pct}
    for r in rows:
        layer = _soil_layer(r.get("short_desc"))
        cat = _soil_cat(r.get("unit_desc"))
        wk = r.get("week_ending")
        val = _num(r.get("Value"))
        if not layer or cat is None or wk is None or val is None:
            continue
        by_layer[layer].setdefault(wk, {})[cat] = int(round(val))
    top_weeks = by_layer["topsoil"]
    if not top_weeks:
        return None
    wk = max(top_weeks)
    top = top_weeks[wk]
    status = _soil_status(top)
    if not status:                       # incomplete category set -> no reliable status
        return None
    out = {"week_ending": wk, "topsoil": top,
           "short_pct": status["short_pct"], "adequate_pct": status["adequate_pct"],
           "surplus_pct": status["surplus_pct"], "balance": status["balance"],
           "status": status["label"], "source": "USDA NASS topsoil moisture survey"}
    sub_weeks = by_layer["subsoil"]
    if sub_weeks:
        sub = sub_weeks.get(wk) or sub_weeks[max(sub_weeks)]
        sub_status = _soil_status(sub)
        if sub_status:
            out["subsoil"] = sub
            out["subsoil_status"] = sub_status["label"]
    return out


_CCI_WEIGHTS = {"excellent": 5, "good": 4, "fair": 3, "poor": 2, "very_poor": 1}


def _cci(cats):
    """USDA-style Crop Condition Index on a 1-5 scale:
    (5·%E + 4·%G + 3·%F + 2·%P + 1·%VP) / 100  (the five category %s sum to 100).
    Returns None if any category is missing. 5 = all Excellent, 1 = all Very Poor.
    """
    if not cats or any(cats.get(k) is None for k in _CCI_WEIGHTS):
        return None
    return round(sum(cats[k] * w for k, w in _CCI_WEIGHTS.items()) / 100.0, 2)


# ----------------------------------------------------------------------------
# Historical per-year YIELD PREDICTORS (for the auto-selecting regression):
# late-season condition (G+E / CCI), growing-season topsoil moisture, silking pace.
# One NASS call each covers all years >= start_year. Archive-free.
# ----------------------------------------------------------------------------
def late_condition_by_year(key, usps, start_year, ref_week=35, last_complete=None):
    """{year: {"ge": %G+E, "cci": 1-5}} at the weekly condition nearest ISO week
    ref_week (late season) for each year — a late-season crop-state predictor.
    With ``last_complete`` set, completed years are served from the permanent cache."""
    if last_complete is not None:
        return _cached_history("cond", usps, start_year, last_complete,
                               lambda: late_condition_by_year(key, usps, start_year, ref_week))
    params = {"statisticcat_desc": "CONDITION", "year__GE": str(start_year)}
    params.update(_scope(usps))
    by = {}
    for r in _api_get(key, params):
        cat = _condition_cat(r.get("short_desc"))
        wk = r.get("week_ending")
        val = _num(r.get("Value"))
        if not cat or not wk or val is None:
            continue
        by.setdefault(int(wk[:4]), {}).setdefault(_week_num(wk), {})[cat] = val
    out = {}
    for y, wks in by.items():
        wk = min(wks, key=lambda w: abs((w or 0) - ref_week))
        c = wks[wk]
        cci = _cci(c)
        ge = (c["good"] + c["excellent"]) if (c.get("good") is not None and c.get("excellent") is not None) else None
        if cci is not None or ge is not None:
            out[y] = {"ge": round(ge, 1) if ge is not None else None, "cci": cci}
    return out


def topsoil_by_year(key, usps, start_year, w0=22, w1=38, last_complete=None):
    """{year: {"short": %, "surplus": %}} — growing-season (ISO wk w0-w1) average
    topsoil dry-share and surplus per year. A moisture-stress predictor.
    With ``last_complete`` set, completed years are served from the permanent cache.

    "short" is the TRUE dry share per week — VERY SHORT + SHORT summed within the
    week, THEN averaged across weeks (pooling both categories into one mean would
    halve the scale and shift it whenever only one category is reported)."""
    if last_complete is not None:
        return _cached_history("soil", usps, start_year, last_complete,
                               lambda: topsoil_by_year(key, usps, start_year, w0, w1))
    params = {"commodity_desc": "SOIL", "statisticcat_desc": "MOISTURE", "year__GE": str(start_year)}
    params.update(_scope(usps))
    dry_wk, su_wk = {}, {}   # (year, week_ending) -> summed dry % / surplus %
    for r in _api_get(key, params):
        sd = (r.get("short_desc") or "").upper()
        if "TOPSOIL" not in sd or "PREVIOUS" in sd:
            continue
        wk = r.get("week_ending")
        val = _num(r.get("Value"))
        if not wk or val is None:
            continue
        w = _week_num(wk)
        if w is None or w < w0 or w > w1:
            continue
        y = int(wk[:4])
        u = (r.get("unit_desc") or "").upper()
        if "SHORT" in u:              # VERY SHORT + SHORT sum to the week's dry share
            dry_wk[(y, wk)] = dry_wk.get((y, wk), 0.0) + val
        elif "SURPLUS" in u and "VERY" not in u:
            su_wk[(y, wk)] = val
    sh, su = {}, {}
    for (y, _wk), v in dry_wk.items():
        sh.setdefault(y, []).append(v)
    for (y, _wk), v in su_wk.items():
        su.setdefault(y, []).append(v)
    out = {}
    for y in set(sh) | set(su):
        out[y] = {"short": round(sum(sh[y]) / len(sh[y]), 1) if sh.get(y) else None,
                  "surplus": round(sum(su[y]) / len(su[y]), 1) if su.get(y) else None}
    return out


def silking_by_year(key, usps, start_year, ref_week=29, last_complete=None):
    """{year: % silking} at the week nearest ISO ref_week — a crop-timing predictor.
    With ``last_complete`` set, completed years are served from the permanent cache."""
    if last_complete is not None:
        return _cached_history("silk", usps, start_year, last_complete,
                               lambda: silking_by_year(key, usps, start_year, ref_week))
    params = {"statisticcat_desc": "PROGRESS", "year__GE": str(start_year)}
    params.update(_scope(usps))
    by = {}
    for r in _api_get(key, params):
        if "SILKING" not in (r.get("short_desc") or "").upper():
            continue
        wk = r.get("week_ending")
        val = _num(r.get("Value"))
        if not wk or val is None:
            continue
        by.setdefault(int(wk[:4]), {})[_week_num(wk)] = val
    out = {}
    for y, wks in by.items():
        out[y] = wks[min(wks, key=lambda w: abs((w or 0) - ref_week))]
    return out


# ----------------------------------------------------------------------------
# panels 4 + 5 + 8: condition (current donut, G+E line w/ bands, season averages)
# ----------------------------------------------------------------------------
def condition_history(key, usps, start_year, current_year):
    """Return weekly condition for start_year..now in one call, processed into:
        {
          latest: {week_ending, excellent, good, fair, poor, very_poor, ge},
          ge_line: {weeks, current, min, median, max},
          season_ge_by_year: {year: mean_ge},   # for the correlation panel
        }

    ``current_year`` is the actual crop year to report on (today's year). Reporting
    is pinned to it so a minor-acreage state that NASS omits from the current weekly
    release does not surface last season's (or an ancient) final rating as if it were
    the current crop. Returns None if the state has no current-year condition.
    """
    params = {"statisticcat_desc": "CONDITION", "year__GE": str(start_year)}
    params.update(_scope(usps))
    rows = _api_get(key, params)
    if not rows:
        return None

    # group by (year, week_ending) -> {category: value}
    weeks = {}
    for r in rows:
        cat = _condition_cat(r.get("short_desc"))
        val = _num(r.get("Value"))
        wk = r.get("week_ending")
        yr = r.get("year")
        if not cat or val is None or not wk or not yr:
            continue
        try:
            yr = int(yr)
        except (ValueError, TypeError):
            continue
        weeks.setdefault((yr, wk), {})[cat] = val

    if not weeks:
        return None

    # per-week G+E — skip a week if either category is suppressed/missing: fabricating
    # an artificially-low G+E from a partial week would poison the bands, ge_by_year
    # and the 'ge' regression predictor. (`is not None` so a legitimate 0 still counts.)
    ge_records = []  # (year, week_ending, iso_week, ge, cats)
    for (yr, wk), cats in weeks.items():
        if cats.get("good") is None or cats.get("excellent") is None:
            continue
        ge = cats["good"] + cats["excellent"]
        ge_records.append((yr, wk, _week_num(wk), round(ge, 1), cats))

    # latest snapshot of the CURRENT crop year (pinned, not max-year-in-data)
    cur_recs = sorted([r for r in ge_records if r[0] == current_year], key=lambda r: r[1])
    if not cur_recs:
        return None  # no current-season condition for this state (e.g. minor acreage)
    latest_rec = cur_recs[-1]
    lc = latest_rec[4]
    latest = {
        "week_ending": latest_rec[1],
        "excellent": lc.get("excellent"),
        "good": lc.get("good"),
        "fair": lc.get("fair"),
        "poor": lc.get("poor"),
        "very_poor": lc.get("very_poor"),
        "ge": latest_rec[3],
    }

    # historical min/median/max by iso-week (years before current)
    from compute import stats as _st
    hist_by_week = {}
    for yr, wk, iso, ge, _cats in ge_records:
        if yr < current_year and iso is not None:
            hist_by_week.setdefault(iso, []).append(ge)

    # current-season line + aligned bands
    weeks_labels, current_vals, mins, meds, maxs = [], [], [], [], []
    for yr, wk, iso, ge, _cats in cur_recs:
        weeks_labels.append(wk[5:])  # MM-DD
        current_vals.append(ge)
        mn, md, mx = _st.safe_stats(hist_by_week.get(iso, []))
        mins.append(mn)
        meds.append(md)
        maxs.append(mx)

    # late-season G+E per year = mean of the final 4 weekly reports (the realized
    # pre-harvest condition) — the strongest predictor of final yield.
    ge_by_year = {}
    by_year = {}
    for yr, wk, iso, ge, _cats in ge_records:
        by_year.setdefault(yr, []).append((wk, ge))
    for yr, recs in by_year.items():
        recs.sort(key=lambda t: t[0])
        late = [ge for _wk, ge in recs[-4:]]
        if late:
            ge_by_year[yr] = round(sum(late) / len(late), 1)

    # --- multi-year weekly evolution (full-season condition chart) ---
    by_iso_year = {}
    for yr, wk, iso, ge, _cats in ge_records:
        if iso is not None:
            by_iso_year[(iso, yr)] = ge
    isos = sorted({iso for iso, _ in by_iso_year})

    def _iso_label(w):
        try:
            return datetime.date.fromisocalendar(2025, w, 7).strftime("%m-%d")
        except (ValueError, TypeError):
            return str(w)

    years_present = sorted({yr for _, yr in by_iso_year})
    prior = [y for y in years_present if y < current_year]
    band_years = prior[-5:]
    show_years = prior[-4:] + [current_year]   # a few comparable years + current
    band_min, band_max = [], []
    for w in isos:
        vals = [by_iso_year[(w, y)] for y in band_years if (w, y) in by_iso_year]
        band_min.append(round(min(vals), 1) if vals else None)
        band_max.append(round(max(vals), 1) if vals else None)

    # current-year latest reported ISO week + a projected week-39 value:
    # current G+E plus prior years' typical (wk39 - same-week) change.
    cur_weeks = [w for (w, y) in by_iso_year if y == current_year]
    current_week = max(cur_weeks) if cur_weeks else None
    proj_wk39 = None
    if current_week is not None and current_week < 39 and 39 in isos:
        cur_val = by_iso_year.get((current_week, current_year))
        deltas = [by_iso_year[(39, y)] - by_iso_year[(current_week, y)]
                  for y in prior
                  if (39, y) in by_iso_year and (current_week, y) in by_iso_year]
        if cur_val is not None and deltas:
            proj_wk39 = round(max(0.0, min(100.0, cur_val + sum(deltas) / len(deltas))), 1)

    ge_evolution = {
        "labels": [_iso_label(w) for w in isos],
        "isos": isos,
        "years": {str(y): [by_iso_year.get((w, y)) for w in isos] for y in show_years},
        "current_year": current_year,
        "current_week": current_week,
        "proj_wk39": proj_wk39,
        "band_min": band_min,
        "band_max": band_max,
        "band_years": [band_years[0], band_years[-1]] if band_years else [],
    }

    # --- CCI (1-5 index) weekly evolution — this is what the "Crop Condition Index"
    #     chart plots (the index, not the raw G+E %). Same shape as ge_evolution. ---
    cci_by_iso_year = {}
    for yr, wk, iso, ge, cats in ge_records:
        if iso is not None:
            v = _cci(cats)
            if v is not None:
                cci_by_iso_year[(iso, yr)] = v
    cci_band_min, cci_band_max = [], []
    for w in isos:
        vals = [cci_by_iso_year[(w, y)] for y in band_years if (w, y) in cci_by_iso_year]
        cci_band_min.append(round(min(vals), 2) if vals else None)
        cci_band_max.append(round(max(vals), 2) if vals else None)
    cci_proj = None
    if current_week is not None and current_week < 39 and 39 in isos:
        cur_val = cci_by_iso_year.get((current_week, current_year))
        deltas = [cci_by_iso_year[(39, y)] - cci_by_iso_year[(current_week, y)]
                  for y in prior
                  if (39, y) in cci_by_iso_year and (current_week, y) in cci_by_iso_year]
        if cur_val is not None and deltas:
            cci_proj = round(max(1.0, min(5.0, cur_val + sum(deltas) / len(deltas))), 2)
    cci_evolution = {
        "labels": [_iso_label(w) for w in isos],
        "isos": isos,
        "years": {str(y): [cci_by_iso_year.get((w, y)) for w in isos] for y in show_years},
        "current_year": current_year,
        "current_week": current_week,
        "proj_wk39": cci_proj,
        "band_min": cci_band_min,
        "band_max": cci_band_max,
        "band_years": [band_years[0], band_years[-1]] if band_years else [],
    }

    # per-iso-week G+E by year (for the week-26 / week-39 correlation, Stage E)
    ge_by_week_year = {}
    for (w, y), ge in by_iso_year.items():
        ge_by_week_year.setdefault(str(w), {})[str(y)] = ge

    # --- condition table (EXC/GOOD/FAIR/POOR/VERY POOR + G+E + CCI):
    #     current week, last week, and multi-year avg for the same ISO week ---
    cats_by_iso_year = {}
    for yr, wk, iso, ge, cats in ge_records:
        if iso is not None:
            cats_by_iso_year[(iso, yr)] = cats
    cur_iso = latest_rec[2]
    avg_years = [y for y in years_present if y < current_year][-15:]

    def _row(c):
        if not c:
            return None
        return {"exc": c.get("excellent"), "good": c.get("good"), "fair": c.get("fair"),
                "poor": c.get("poor"), "vpoor": c.get("very_poor"),
                "ge": round((c.get("good") or 0) + (c.get("excellent") or 0), 1),
                "cci": _cci(c)}

    avg_cats = {}
    for k in ("excellent", "good", "fair", "poor", "very_poor"):
        vals = [cats_by_iso_year[(cur_iso, y)].get(k) for y in avg_years
                if (cur_iso, y) in cats_by_iso_year and cats_by_iso_year[(cur_iso, y)].get(k) is not None]
        avg_cats[k] = round(sum(vals) / len(vals), 1) if vals else None
    last_cats = cur_recs[-2][4] if len(cur_recs) >= 2 else None

    condition_table = {
        "week": cur_iso,
        "week_ending": latest_rec[1],
        "current": _row(lc),
        "last_week": _row(last_cats),
        "avg": _row(avg_cats),
        "avg_years": len(avg_years),
    }

    return {
        "latest": latest,
        # slimmed: only .current is ever rendered (KPI weekly change + overview map);
        # the min/median/max bands were superseded by the CCI/G+E evolution charts
        "ge_line": {"current": current_vals, "current_year": current_year},
        "ge_by_year": ge_by_year,
        "ge_evolution": ge_evolution,
        "cci_evolution": cci_evolution,
        "ge_by_week_year": ge_by_week_year,
        "condition_table": condition_table,
    }


# ----------------------------------------------------------------------------
# panels 6 + 7: yield (curve + trend) and detrended deviation
# ----------------------------------------------------------------------------
def yield_series(key, usps, start_year):
    params = {
        "statisticcat_desc": "YIELD",
        "short_desc": "CORN, GRAIN - YIELD, MEASURED IN BU / ACRE",
        "freq_desc": "ANNUAL",
        "year__GE": str(start_year),
    }
    params.update(_scope(usps))
    rows = _api_get(key, params)
    # From August NASS also publishes in-season FORECAST vintages ("YEAR - AUG
    # FORECAST", ... - SEP/OCT/NOV) under freq ANNUAL. Only the final "YEAR" row is a
    # realized yield; a forecast must never enter the series (it would feed the trend
    # fit, the detrended deviations and the regression training as if it were real).
    by_year = {}   # year -> (rank, value); higher rank wins (later/finaler vintage)
    _RANK = {"YEAR": 5, "YEAR - NOV FORECAST": 4, "YEAR - OCT FORECAST": 3,
             "YEAR - SEP FORECAST": 2, "YEAR - AUG FORECAST": 1}
    for r in rows:
        val = _num(r.get("Value"))
        yr = r.get("year")
        if val is None or not yr:
            continue
        try:
            yr = int(yr)
        except (ValueError, TypeError):
            continue
        ref = (r.get("reference_period_desc") or "").upper()
        rank = _RANK.get(ref, 0)
        if rank == 0:
            continue
        if yr not in by_year or rank > by_year[yr][0]:
            by_year[yr] = (rank, val)
    finals = {y: rv[1] for y, rv in by_year.items() if rv[0] == 5}   # realized only
    if not finals:
        return None
    years = sorted(finals)
    return {"years": years, "values": [finals[y] for y in years]}


def acres_by_year(key, usps, start_year):
    """Planted vs harvested corn acres per year + the implied abandonment %.

    Production = yield x acres; the dashboard models the yield half, and acreage
    swings / prevented-plant years (a wide planted-vs-harvested gap) are the other
    half of the June-July decision. Realized "YEAR" rows only, like yield_series.
    """
    out = {}   # year -> {"planted": ac, "harvested": ac}
    for cat, field, sd in (("AREA PLANTED", "planted", "CORN - ACRES PLANTED"),
                           ("AREA HARVESTED", "harvested",
                            "CORN, GRAIN - ACRES HARVESTED")):
        params = {"statisticcat_desc": cat, "short_desc": sd,
                  "freq_desc": "ANNUAL", "year__GE": str(start_year)}
        params.update(_scope(usps))
        for r in _api_get(key, params):
            if (r.get("reference_period_desc") or "").upper() != "YEAR":
                continue   # skip PROSPECTIVE PLANTINGS / in-season forecast vintages
            val = _num(r.get("Value"))
            yr = r.get("year")
            if val is None or not yr:
                continue
            try:
                out.setdefault(int(yr), {})[field] = val
            except (TypeError, ValueError):
                continue
    years = sorted(y for y in out if out[y].get("planted"))
    if not years:
        return None
    planted = [out[y].get("planted") for y in years]
    harvested = [out[y].get("harvested") for y in years]
    aband = [round((1 - h / p) * 100, 1) if (h and p) else None
             for p, h in zip(planted, harvested)]
    return {"years": years, "planted": planted, "harvested": harvested,
            "abandon_pct": aband, "unit": "acres"}


_MONTH_ABBR = {"JAN": 1, "FEB": 2, "MAR": 3, "APR": 4, "MAY": 5, "JUN": 6,
               "JUL": 7, "AUG": 8, "SEP": 9, "OCT": 10, "NOV": 11, "DEC": 12}


def price_received(key, usps, start_year):
    """Monthly average price received ($/bu) — the only price signal reachable
    inside the firewall (same NASS host). ~2-month survey lag: context, not a
    live quote, and the UI must say so."""
    params = {"statisticcat_desc": "PRICE RECEIVED",
              "short_desc": "CORN, GRAIN - PRICE RECEIVED, MEASURED IN $ / BU",
              "freq_desc": "MONTHLY", "year__GE": str(start_year)}
    params.update(_scope(usps))
    pts = {}   # (year, month) -> $/bu
    for r in _api_get(key, params):
        m = _MONTH_ABBR.get((r.get("reference_period_desc") or "").strip().upper()[:3])
        val = _num(r.get("Value"))
        yr = r.get("year")
        if m is None or val is None or not yr:
            continue
        try:
            pts[(int(yr), m)] = val
        except (TypeError, ValueError):
            continue
    if not pts:
        return None
    keys = sorted(pts)
    labels = [f"{y}-{m:02d}" for y, m in keys]
    values = [pts[k] for k in keys]
    return {"labels": labels, "values": values,
            "latest": values[-1], "latest_month": labels[-1], "unit": "$/bu"}


# ----------------------------------------------------------------------------
# corn-region weighting: county production -> top counties
# ----------------------------------------------------------------------------
def all_state_production(key, year):
    """One call: {state_alpha: corn grain production (bu)} for every state in ``year``."""
    rows = _api_get(key, {
        "statisticcat_desc": "PRODUCTION",
        "agg_level_desc": "STATE",
        "short_desc": "CORN, GRAIN - PRODUCTION, MEASURED IN BU",
        "year": str(year),
    })
    best = {}  # usps -> (is_year_ref, value) ; prefer reference_period_desc == YEAR
    for r in rows:
        val = _num(r.get("Value"))
        us = (r.get("state_alpha") or "").strip().upper()
        if val is None or not us:
            continue
        is_year = (r.get("reference_period_desc") or "").upper() == "YEAR"
        if us not in best or (is_year and not best[us][0]):
            best[us] = (is_year, val)
    return {us: v for us, (_iy, v) in best.items()}


def national_production(key, year):
    """US total corn grain production (bu) for ``year``, or None."""
    rows = _api_get(key, {
        "statisticcat_desc": "PRODUCTION",
        "agg_level_desc": "NATIONAL",
        "short_desc": "CORN, GRAIN - PRODUCTION, MEASURED IN BU",
        "year": str(year),
    })
    for want_year in (True, False):
        for r in rows:
            is_year = (r.get("reference_period_desc") or "").upper() in ("YEAR", "")
            if is_year == want_year or not want_year:
                v = _num(r.get("Value"))
                if v:
                    return v
    return None


def county_production(key, usps, year):
    """Return list of (county_fips5, production_bu) for one state/year.

    Historical county production is immutable once published, so non-empty results
    cache permanently (empty results are NOT cached — a not-yet-published year must
    keep retrying until NASS releases it)."""
    ckey = f"nasscounty:{usps}:{year}"
    hit = cache.get_json(ckey)
    if hit is not None:
        return [(f, v) for f, v in hit]
    rows = _api_get(key, {
        "statisticcat_desc": "PRODUCTION",
        "agg_level_desc": "COUNTY",
        "state_alpha": usps,
        "short_desc": "CORN, GRAIN - PRODUCTION, MEASURED IN BU",
        "year": str(year),
    })
    out = []
    for r in rows:
        val = _num(r.get("Value"))
        if val is None:
            continue
        st = (r.get("state_ansi") or r.get("state_fips_code") or "").zfill(2)
        co = (r.get("county_ansi") or r.get("county_code") or "").strip()
        if not co or not co.isdigit():
            continue  # skip "other (combined) counties"
        fips = st + co.zfill(3)
        out.append((fips, val))
    if out:
        cache.set_json(ckey, out)
    return out
